# Experiment f456b422c23349f0bb681b058ecdae31d173b321f4907d142f7879e4caf22699

Mode: pipeline. Complete paired blocks: 0/1.
Correctness failed: True. Retained unsuccessful attempts: 1.
Performance conclusion valid: False.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |

## Failures

- `babe6a5e91554f0688818c430fe8aca0`: model_mismatch (warmup:0:fixture:1:candidate)
