# Experiment c329f4a7579b8d763a27216c36c535222a0e5d8afac7f4685306fa6e2167d152

Mode: core. Complete paired blocks: 1/1.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 12.978248280342942 |

## Failures

None.
