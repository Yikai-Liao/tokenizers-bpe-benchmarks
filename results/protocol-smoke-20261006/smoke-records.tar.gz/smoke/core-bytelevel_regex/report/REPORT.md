# Experiment 1954f7b9e8c3606d701f5180487021ccae4294550d2754bcc473f5f1c103be56

Mode: core. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 2.743020667211832 |
| fixture | 2 | candidate | 4.1978583535999885 |

## Failures

None.
