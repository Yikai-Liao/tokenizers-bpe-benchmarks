# Experiment 059953693f14a880fc39b678c84a92a285e9c54c047203df5183f821362f1390

Mode: pipeline. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 4.33557015087943 |
| fixture | 2 | candidate | 3.0739728578157193 |

## Failures

None.
