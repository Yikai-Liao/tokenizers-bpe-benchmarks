# Experiment 070f166b4db8050aecaa02d16c8685c619bb6860839495e4c80dc698462e9914

Mode: pipeline. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 4.907014282358315 |
| fixture | 2 | candidate | 4.294609072346951 |

## Failures

None.
