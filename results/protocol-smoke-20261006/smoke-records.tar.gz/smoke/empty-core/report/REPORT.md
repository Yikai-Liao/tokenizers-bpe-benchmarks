# Experiment 558533dec967d890bee19bbc8c4069fb4517e2f64bfdd430f1612f8b8a630062

Mode: core. Complete paired blocks: 2/2.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 15.878886620034468 |
| fixture | 2 | candidate | 14.003884549163296 |

## Failures

None.
