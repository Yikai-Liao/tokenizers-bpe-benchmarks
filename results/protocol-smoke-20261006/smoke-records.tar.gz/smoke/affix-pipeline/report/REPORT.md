# Experiment f7df372f27e6a16b0155bcda4138a9506469a5cd32dbd1073bf4a76c0e63827c

Mode: pipeline. Complete paired blocks: 1/1.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 7.777046502690239 |

## Failures

None.
