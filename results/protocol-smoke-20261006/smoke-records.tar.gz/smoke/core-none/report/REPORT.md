# Experiment 48d7b91d331b07e9c01b3c0ff858507f368a5391071f09b4ef24330a53f3ff4f

Mode: core. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 2.3566912997499605 |
| fixture | 2 | candidate | 4.379604946308071 |

## Failures

None.
