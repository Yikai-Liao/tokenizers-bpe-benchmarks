# Experiment b95a3e9dc7d44ba1a6545195aa21c810950ba0876f7dadfd35fc60420042f4f3

Mode: core. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 6.236109408197793 |
| fixture | 2 | candidate | 4.704283346796904 |

## Failures

None.
