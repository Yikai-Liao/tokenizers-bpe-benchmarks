# Experiment 1aa0c75f7371ece86500f847cca9c92f0252d743702ac37b23d4218f0318edfe

Mode: pipeline. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 3.2004090261247695 |
| fixture | 2 | candidate | 3.0096266539250167 |

## Failures

None.
