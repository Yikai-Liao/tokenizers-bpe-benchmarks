# Experiment 597f85b150ed4cd06be32d0c4866d33b28ef9a37b5260fbbacd9d1f602ebbc7f

Mode: pipeline. Complete paired blocks: 2/2.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 8.371601668921107 |
| fixture | 2 | candidate | 9.409066062262516 |

## Failures

None.
