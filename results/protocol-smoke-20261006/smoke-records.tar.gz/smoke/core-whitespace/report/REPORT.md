# Experiment 498d75d66ec2788889002ed0bafd487e2737e774034e6bb9e2aaa380388bcd74

Mode: core. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 5.4807052058860055 |
| fixture | 2 | candidate | 4.980891455192406 |

## Failures

None.
