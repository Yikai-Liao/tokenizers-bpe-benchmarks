# Experiment 7a2454c93f57dedc7de0167b4c98142287c47d113010404749a7ae0859cd279a

Mode: pipeline. Complete paired blocks: 4/4.
Correctness failed: False. Retained unsuccessful attempts: 0.
Performance conclusion valid: True.

Paired ratios use candidate / baseline within each complete block. Ranges are observed minimum/maximum, not confidence intervals.
Process HWM includes startup and loading up to the pre-serialization boundary; sampled RSS includes the entire child process.

| Case | Workers | Arm | Wall ratio |
| --- | ---: | --- | ---: |
| fixture | 1 | candidate | 6.517958191900609 |
| fixture | 2 | candidate | 5.966042698461063 |

## Failures

None.
