use super::{
    lattice::Lattice,
    trie::{Trie, TrieBuilder},
};
use crate::utils::word_cache::{Lookup, WordCache};
use crate::{
    pipeline::{self, PipelineToken},
    tokenizer::{Result, Token},
};
use crate::{
    utils::cache::{Cache, MAX_LENGTH},
    vocab::bucket_vocab_store::BucketVocabStore,
};
use std::collections::HashMap;

use std::convert::TryInto;

pub(crate) type Vocab = Vec<(String, f64)>;

/// A `Unigram` model to encode sentences.
pub struct Unigram {
    token_to_ids: BucketVocabStore,
    pub(crate) vocab: Vocab,
    cache: Cache<String, Vec<String>>,
    trie: Trie<u8>,
    pub min_score: f64,
    pub(super) unk_id: Option<usize>,
    pub bos_id: usize,
    pub eos_id: usize,

    fuse_unk: bool,
    is_optimized: bool,
    byte_fallback: bool,

    pub alpha: Option<f64>,
    pub nbest_size: Option<usize>,
}
impl PartialEq for Unigram {
    fn eq(&self, other: &Self) -> bool {
        self.unk_id == other.unk_id
            && self.vocab == other.vocab
            && self.alpha == other.alpha
            && self.nbest_size == other.nbest_size
    }
}

impl Clone for Unigram {
    // `Clone` can't be derive because it's not implemented for `Cache`.
    // To keep things simple when we clone, the new Unigram will start with a fresh cache.
    fn clone(&self) -> Self {
        let fresh_cache = self.cache.fresh();
        Self {
            vocab: self.vocab.clone(),
            cache: fresh_cache,
            token_to_ids: self.token_to_ids.clone(),
            trie: self.trie.clone(),
            min_score: self.min_score,
            unk_id: self.unk_id,
            bos_id: self.bos_id,
            eos_id: self.eos_id,
            fuse_unk: self.fuse_unk,
            is_optimized: self.is_optimized,
            byte_fallback: self.byte_fallback,
            alpha: self.alpha,
            nbest_size: self.nbest_size,
        }
    }
}

impl std::fmt::Debug for Unigram {
    fn fmt(&self, fmt: &mut std::fmt::Formatter) -> std::fmt::Result {
        fmt.debug_struct("Unigram")
            .field("vocab", &self.vocab.len())
            .field("unk_id", &self.unk_id)
            .field("byte_fallback", &self.byte_fallback)
            .finish()
    }
}

static K_UNK_PENALTY: f64 = 10.0;

#[derive(thiserror::Error, Debug)]
pub enum UnigramError {
    #[error("The vocabulary is empty but at least <unk> is needed")]
    EmptyVocabulary,
    #[error("The `unk_id` is larger than vocabulary size")]
    UnkIdNotInVocabulary,
    #[error("Encountered an unknown token but `unk_id` is missing")]
    MissingUnkId,
}

impl Default for Unigram {
    fn default() -> Self {
        let vocab = vec![("<unk>".to_string(), 0.0)];
        Self::from(vocab, Some(0), false).unwrap()
    }
}

impl Unigram {
    /// Create a `Unigram` model from a given vocabulary.
    /// Vocabulary are the various tokens and their associated score which is a sort of a logprob of
    /// their frequency, which will enable tokenization and sampling.
    /// unk_id, is the index within the vocabulary.
    /// For now `Unigram` *requires* at least `unk` because we might find a never seen char.
    /// Further versions might allow that part to be hidden.
    pub fn from(
        vocab: Vec<(String, f64)>,
        unk_id: Option<usize>,
        byte_fallback: bool,
    ) -> Result<Self> {
        let n = vocab.len();
        let mut pairs: Vec<(Vec<u8>, u32)> = Vec::with_capacity(n);
        let mut builder = TrieBuilder::default();

        if let Some(unk_id) = unk_id {
            if vocab.is_empty() {
                return Err(Box::new(UnigramError::EmptyVocabulary));
            }
            if unk_id >= vocab.len() {
                return Err(Box::new(UnigramError::UnkIdNotInVocabulary));
            }
        }
        let bos_id = n + 1;
        let eos_id = n + 2;

        let mut min_score = f64::INFINITY;
        for (id, (token, score)) in vocab.iter().enumerate() {
            pairs.push((token.as_bytes().to_vec(), id as u32));
            builder.push(token.as_bytes());
            if score < &min_score {
                min_score = *score;
            }
        }
        let token_to_ids = if pairs.is_empty() {
            BucketVocabStore::new()
        } else {
            BucketVocabStore::build(pairs)
        };
        let trie = builder.build();
        let fuse_unk = true;
        let is_optimized = true;

        Ok(Self {
            vocab,
            token_to_ids,
            trie,
            min_score,
            bos_id,
            eos_id,
            unk_id,
            fuse_unk,
            cache: Cache::default(),
            is_optimized,
            byte_fallback,
            alpha: None,
            nbest_size: None,
        })
    }

    #[cfg(test)]
    pub(super) fn set_fuse_unk(&mut self, fuse_unk: bool) {
        self.fuse_unk = fuse_unk;
        self.cache = self.cache.fresh();
    }

    #[cfg(test)]
    pub(super) fn set_optimized(&mut self, is_optimized: bool) {
        self.is_optimized = is_optimized;
    }
    pub fn byte_fallback(&self) -> bool {
        self.byte_fallback
    }
    pub fn len(&self) -> usize {
        self.vocab.len()
    }
    pub fn is_empty(&self) -> bool {
        self.vocab.is_empty()
    }

    pub fn populate_nodes(&self, lattice: &mut Lattice) {
        let unk_score = self.min_score - K_UNK_PENALTY;

        let len = lattice.len();

        let mut begin_pos = 0;
        while begin_pos < len {
            let mblen = lattice.sentence[begin_pos..]
                .chars()
                .next()
                .unwrap()
                .len_utf8();

            let mut has_single_node = false;

            for bytes in self
                .trie
                .common_prefix_search(lattice.sentence.bytes().skip(begin_pos))
            {
                let n = bytes.len();
                let tok = String::from_utf8(bytes).unwrap();
                let id = self.token_to_ids.token_to_id(&tok).unwrap();

                let item = &self.vocab[id as usize];
                assert_eq!(item.0, tok);
                let score: f64 = item.1;
                lattice.insert(begin_pos, n, score, id.try_into().unwrap());
                if !has_single_node && n == mblen {
                    has_single_node = true;
                }
            }

            if !has_single_node && let Some(unk_id) = self.unk_id {
                lattice.insert(begin_pos, mblen, unk_score, unk_id);
            }
            begin_pos += mblen
        }
    }

    /// This functions take a String, and will encode it in a Vec of Strings,
    /// of the best tokenization available to the current model.
    /// ```
    /// use tk_encode::models::unigram::Unigram;
    ///
    /// let pieces = vec![
    ///     ("<unk>".to_string(), 0.0),
    ///     ("a".to_string(), 0.0),
    ///     ("b".to_string(), 0.0),
    ///     ("c".to_string(), 0.0),
    ///     ("d".to_string(), 0.0),
    ///     ("cd".to_string(), 1.0),
    ///     ("ab".to_string(), 2.0),
    ///     ("abc".to_string(), 5.0),
    ///     ("abcd".to_string(), 10.0),
    /// ];
    /// let model = Unigram::from(pieces, Some(0), false).unwrap();
    /// let result = model.encode("abcdacdxx").unwrap();
    /// assert_eq!(result, vec!["abcd", "a", "cd", "xx"]);
    /// ```
    pub fn encode(&self, sentence: &str) -> Result<Vec<String>> {
        if sentence.is_empty() {
            return Ok(vec![]);
        }
        if self.samples() {
            return self.encode_uncached(sentence);
        }
        if let Some(result) = self.cache.get(sentence) {
            return Ok(result.to_vec());
        }
        let result = self.encode_uncached(sentence)?;
        if sentence.len() < MAX_LENGTH {
            self.cache.set(sentence.to_owned(), result.clone());
        }
        Ok(result)
    }

    /// Whether [`Unigram::alpha`] asks for a tokenization drawn at random from the
    /// lattice instead of its best path. Such a result is one draw out of many, so no
    /// cache may hold it.
    fn samples(&self) -> bool {
        matches!(self.alpha, Some(alpha) if alpha != 0.0)
    }

    /// What `sentence` encodes to, worked out rather than looked up: the lattice's
    /// best path, or a draw from it when [`Unigram::samples`].
    fn encode_uncached(&self, sentence: &str) -> Result<Vec<String>> {
        if self.is_optimized && !self.samples() {
            self.encode_optimized(sentence)
        } else {
            self.encode_unoptimized(sentence)
        }
    }

    fn encode_optimized(&self, sentence: &str) -> Result<Vec<String>> {
        // https://github.com/google/sentencepiece/blob/d48247191a6d50e469ed1a4a36e877befffd1851/src/unigram_model.cc#L600
        #[derive(Debug, Clone)]
        struct BestPathNode {
            /// The vocab id. (maybe UNK)
            id: usize,
            /// The total score of the best path ending at this node.
            best_path_score: f64,
            /// The starting position (in utf-8) of this node. The entire best
            /// path can be constructed by backtracking along this link.
            starts_at: Option<usize>,
        }
        impl Default for BestPathNode {
            fn default() -> Self {
                Self {
                    id: 0,
                    best_path_score: 0.0,
                    starts_at: None,
                }
            }
        }
        let size = sentence.len();
        let unk_score = self.min_score - K_UNK_PENALTY;

        let mut best_path_ends_at = vec![BestPathNode::default(); size + 1];
        let mut starts_at = 0;
        while starts_at < size {
            let best_path_score_till_here = best_path_ends_at[starts_at].best_path_score;
            let mut has_single_node = false;
            let mblen = sentence[starts_at..].chars().next().unwrap().len_utf8();
            for tok_bytes in self
                .trie
                .common_prefix_search(sentence.bytes().skip(starts_at))
            {
                let key_pos = starts_at + tok_bytes.len();
                let token: String = String::from_utf8(tok_bytes).unwrap();
                let target_node = &mut best_path_ends_at[key_pos];
                let length = key_pos - starts_at;
                let id = self.token_to_ids.token_to_id(&token).unwrap();
                let score = self.vocab.get(id as usize).unwrap().1;
                let candidate_best_path_score = score + best_path_score_till_here;
                if target_node.starts_at.is_none()
                    || candidate_best_path_score > target_node.best_path_score
                {
                    target_node.best_path_score = candidate_best_path_score;
                    target_node.starts_at = Some(starts_at);
                    target_node.id = id as usize;
                }
                if !has_single_node && length == mblen {
                    has_single_node = true;
                }
            }
            if !has_single_node {
                let target_node = &mut best_path_ends_at[starts_at + mblen];
                let candidate_best_path_score = unk_score + best_path_score_till_here;
                if target_node.starts_at.is_none()
                    || candidate_best_path_score > target_node.best_path_score
                {
                    target_node.best_path_score = candidate_best_path_score;
                    target_node.starts_at = Some(starts_at);
                    target_node.id = self.unk_id.ok_or(UnigramError::MissingUnkId)?;
                }
            }
            starts_at += mblen
        }
        let mut ends_at = size;
        let mut results: Vec<String> = vec![];
        let mut token = vec![];
        while ends_at > 0 {
            let node = &best_path_ends_at[ends_at];
            let starts_at = node.starts_at.unwrap();
            if self.fuse_unk && Some(node.id) == self.unk_id {
                token.push(sentence[starts_at..ends_at].to_string());
            } else {
                if !token.is_empty() {
                    token.reverse();
                    results.push(token.concat());
                    token = vec![];
                }
                results.push(sentence[starts_at..ends_at].to_string());
            }
            ends_at = starts_at;
        }
        if !token.is_empty() {
            token.reverse();
            results.push(token.concat());
        }
        results.reverse();
        Ok(results)
    }

    fn encode_unoptimized(&self, sentence: &str) -> Result<Vec<String>> {
        let mut lattice = Lattice::from(sentence, self.bos_id, self.eos_id);
        self.populate_nodes(&mut lattice);
        let path = match (self.nbest_size, self.alpha) {
            (Some(n), Some(alpha)) if n > 0 => lattice.sample_nbest(n, alpha),
            (_, Some(alpha)) => lattice.sample(alpha),
            _ => lattice.viterbi(),
        };
        if self.fuse_unk {
            let mut results = vec![];
            let mut token = String::new();
            for node in path.iter() {
                let item = lattice.piece(&node.borrow());
                if node.borrow().id == self.unk_id.ok_or(UnigramError::MissingUnkId)? {
                    token.push_str(&item);
                } else {
                    if !token.is_empty() {
                        results.push(token);
                        token = String::new();
                    }
                    results.push(item);
                }
            }
            if !token.is_empty() {
                results.push(token);
            }
            Ok(results)
        } else {
            let results: Vec<String> = path
                .iter()
                .map(|node| lattice.piece(&node.borrow()))
                .collect();
            Ok(results)
        }
    }

    /// Iterate of vocabulary of the model as a pair of `(token, score)`.
    pub fn iter(&self) -> UnigramIterator<'_> {
        UnigramIterator { model: self, i: 0 }
    }

    /// The id of the unknown-token entry, if this model declares one.
    ///
    /// This and [`Self::vocab`] exist for `tk-convert`'s serde mirror: the fields themselves are
    /// crate-private, and a `unigram.json` is written from exactly these three values plus
    /// [`Self::byte_fallback`].
    pub fn unk_id(&self) -> Option<usize> {
        self.unk_id
    }

    /// The `(token, score)` table, in id order. [`Self::iter`] is the same data, one entry at a
    /// time.
    pub fn vocab(&self) -> &[(String, f64)] {
        &self.vocab
    }

    /// Clears the internal cache
    pub fn clear_cache(&mut self) {
        self.cache.clear();
    }

    /// Resize the cache
    pub fn resize_cache(&mut self, capacity: usize) {
        self.cache.resize(capacity);
    }
}

/// Iterator to iterate of vocabulary of the model, and their relative score.
pub struct UnigramIterator<'a> {
    model: &'a Unigram,
    i: usize,
}

impl<'a> Iterator for UnigramIterator<'a> {
    type Item = &'a (String, f64);

    fn next(&mut self) -> Option<Self::Item> {
        let i = self.i;
        if i < self.model.len() {
            let r = Some(&self.model.vocab[i]);
            self.i += 1;
            r
        } else {
            None
        }
    }
}

/// The model methods the pipeline and the readers call. These used to be the legacy
/// `Model` trait; that trait had no implementor left that needed polymorphism, so they are
/// plain inherent methods now and every call site is unchanged.
impl Unigram {
    pub fn get_vocab(&self) -> HashMap<String, u32> {
        self.token_to_ids.get_vocab().into_iter().collect()
    }

    pub fn get_vocab_size(&self) -> usize {
        self.vocab.len()
    }

    pub fn tokenize(&self, sentence: &str) -> Result<Vec<Token>> {
        let str_tokens = self.encode(sentence)?;
        let mut offset = 0;
        let mut tokens = Vec::with_capacity(str_tokens.len());
        for string in str_tokens {
            let len = string.len();
            let offsets = (offset, offset + len);
            let id: u32 = match self.token_to_ids.token_to_id(&string) {
                Some(id) => id,
                None => {
                    if self.byte_fallback {
                        let byte_tokens: Option<Vec<_>> = string
                            .bytes()
                            .map(|byte| -> Option<Token> {
                                let byte_string = format!("<0x{byte:02X}>");
                                let id = self.token_to_ids.token_to_id(&byte_string);
                                id.map(|id| Token::new(id, byte_string, (offset, offset + len)))
                            })
                            .collect();
                        if let Some(byte_tokens) = byte_tokens {
                            for token in byte_tokens {
                                tokens.push(token);
                            }
                            offset += len;
                            continue;
                        }
                    }
                    self.unk_id.ok_or(UnigramError::MissingUnkId)? as u32
                }
            };
            offset += len;
            tokens.push(Token::new(id, string, offsets));
        }
        Ok(tokens)
    }

    pub fn token_to_id(&self, token: &str) -> Option<u32> {
        self.token_to_ids.token_to_id(token)
    }

    pub fn id_to_token(&self, id: u32) -> Option<String> {
        self.vocab.get(id as usize).map(|item| item.0.clone())
    }
}

pub struct UnigramScratch {
    /// Outlives the encode call that fills it, or it would never see a word twice.
    pub(crate) word_cache: Option<WordCache>,
}

impl pipeline::ModelScratch for UnigramScratch {}

impl pipeline::Model for Unigram {
    type Scratch = UnigramScratch;

    fn init_scratch(&self) -> Self::Scratch {
        Self::Scratch {
            word_cache: match self.cache.capacity {
                0 => None,
                capacity => Some(WordCache::new(capacity)),
            },
        }
    }

    /// The pipeline asks for ids and nothing else, so this path caches ids, where
    /// [`Unigram::encode`] has to hand back the pieces themselves and caches those. A hit
    /// skips the lattice, the `String` every piece is built into, and the vocabulary
    /// lookup that turns each one back into an id.
    fn tokenize_pipeline(
        &self,
        sequence: &str,
        scratch: &mut Self::Scratch,
        output: &mut Vec<pipeline::PipelineToken>,
    ) -> Result<()> {
        if sequence.is_empty() {
            return Ok(());
        }
        let mut placement = None;
        if !self.samples()
            && let Some(cache) = scratch.word_cache.as_mut()
        {
            match cache.lookup(sequence.as_bytes()) {
                Lookup::Hit(ids) => {
                    output.extend(ids.iter().copied().map(PipelineToken::from));
                    return Ok(());
                }
                Lookup::Miss(at) => placement = Some(at),
            }
        }

        let start = output.len();
        for string in self.encode_uncached(sequence)? {
            match self.token_to_ids.token_to_id(&string) {
                Some(id) => {
                    output.push(PipelineToken::from(id));
                }
                None => {
                    if self.byte_fallback {
                        let byte_token_ids: Option<Vec<_>> = string
                            .bytes()
                            .map(|byte| {
                                let byte_string = format!("<0x{byte:02X}>");
                                self.token_to_ids.token_to_id(&byte_string)
                            })
                            .collect();
                        if let Some(token_ids) = byte_token_ids {
                            output.extend(token_ids.iter().copied().map(PipelineToken::from));
                            continue;
                        }
                    }
                    output.push(PipelineToken::from(
                        self.unk_id.ok_or(UnigramError::MissingUnkId)? as u32,
                    ));
                }
            };
        }

        // Sampling skipped the lookup, so `placement` is `None` and this stores
        // nothing, which is what `samples` says has to happen.
        if let Some(cache) = scratch.word_cache.as_mut()
            && let Some(at) = placement
        {
            cache.insert(at, output[start..].iter().map(|token| token.id()));
        }
        Ok(())
    }
}
