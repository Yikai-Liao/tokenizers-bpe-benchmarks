use std::collections::BTreeMap;
use std::iter::Enumerate;
use std::sync::Arc;
use std::vec::IntoIter;

#[cfg(feature = "unigram")]
use crate::models::unigram::{Unigram, UnigramScratch};
#[cfg(feature = "wordlevel")]
use crate::models::wordlevel::WordLevel;
#[cfg(feature = "wordpiece")]
use crate::models::wordpiece::{PipelineWordPiece, WordPieceScratch};
pub use crate::pipeline::encode_options::EncodeOptions;
pub use crate::pipeline::encode_options::Override;
use crate::utils::truncation::truncate_pair;
use crate::{
    DecoderRuntime, PaddingParams, TruncationParams,
    models::bpe::{BpeScratch, PipelineBPE},
    pad_encodings,
    pipeline::scratch_pool::{EncodeScratch, ScratchPool},
    tokenizer::Decoder as _,
    vocab::bucket_added_vocabulary::AddedVocabulary as BucketAddedVocabulary,
};
#[cfg(feature = "parallelism")]
pub use parallel::PARALLEL_MIN_BYTES;
#[cfg(feature = "parallelism")]
use parallel::StreamingIter;

use super::Result;

pub mod encode_options;
#[cfg(feature = "parallelism")]
mod parallel;
mod scratch_pool;

pub use scratch_pool::ModelScratch;

pub use bitcannon::Span;

mod normalizer;
mod post_processor;
mod pre_tokenizer;

pub use normalizer::{Normalizer, NormalizerChain, PipelineNormalizer, normalize_all};
pub use post_processor::{PipelinePostProcessor, Template};
pub use pre_tokenizer::{
    PipelinePreTokenizer, PreTokenizer, PreTokenizerScratch, SplitPolicy, split, split_delimiter,
    split_matches,
};

/// An output token. Carries only the vocabulary `id`, since offsets and the token
/// string are dropped, which is all an encode-only caller needs.
///
/// TODO: For RC0 this is abolutely fine. For v1, we need an enum, Token or Encoding, which can
/// both be outputed by the pipeline.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(transparent)]
pub struct PipelineToken(u32);

impl PipelineToken {
    /// The vocabulary id this token stands for.
    pub const fn id(self) -> u32 {
        self.0
    }
}

impl From<u32> for PipelineToken {
    fn from(value: u32) -> Self {
        Self(value)
    }
}

impl From<PipelineToken> for u32 {
    fn from(value: PipelineToken) -> Self {
        value.0
    }
}

/// Compares a token against a bare id, so a caller can assert against `[u32]`
/// without mapping the ids out first.
impl PartialEq<u32> for PipelineToken {
    fn eq(&self, id: &u32) -> bool {
        self.0 == *id
    }
}

impl PartialEq<PipelineToken> for u32 {
    fn eq(&self, token: &PipelineToken) -> bool {
        *self == token.0
    }
}

/// Finds special/added tokens in a text segment so the pipeline can carve them
/// out before running the model.
pub trait PipelinePatternMatcher {
    /// Return the first special or added token in `input` as `Some(((start, end), id))`, where
    /// `start..end` is its byte range.
    ///
    /// Set `normalized` to true when the text is normalized.
    /// Set `encode_special_tokens` to `true` to treat special tokens as plain text and encode
    /// them through the tokenizer model, or `false` to extract them.
    ///
    /// Returns `None` if there are no added tokens left in `input`.
    fn extract_next(
        &self,
        full_input: &[u8],
        search_offset: usize,
        normalized: bool,
        encode_special_tokens: bool,
    ) -> Option<((usize, usize), u32)>;
}

/// A piece of the input produced by [`SpecialSegmentIterator`].
pub enum Segment<'a> {
    /// Ordinary text still to be (optonally normalized), pre-tokenized and run through the model.
    /// input_offset is the start position of `text` in the input
    Text { text: &'a str, input_offset: usize },
    /// A matched special token, identified by its vocabulary id.
    SpecialToken(u32),
}

/// Splits `input` into [`Segment`]s, in order: runs of ordinary text
/// ([`Segment::Text`]) interleaved with the special tokens
/// ([`Segment::SpecialToken`]) matched by the [`PipelinePatternMatcher`].
///
/// ```ignore
/// for segment in SpecialSegmentIterator::new(input, pattern_matcher, false, false) {
///     match segment {
///         Segment::SpecialToken(id) => { /* emit the special token */ }
///         Segment::Text { text, input_offset } => { /* tokenize this chunk */ }
///     }
/// }
/// ```
pub struct SpecialSegmentIterator<'a, 'b, PatternMatcher: PipelinePatternMatcher> {
    /// The chunk of text from which we want to extract special tokens
    input: &'a str,
    /// Implementor of [`PipelinePatternMatcher`] - the engine to match special tokens
    pattern_matcher: &'b PatternMatcher,
    /// Whether the input is normalized
    normalized: bool,
    /// [`EncodeOptions::encode_special_tokens`], forwarded to `extract_next` on every match
    encode_special_tokens: bool,
    offset: usize,
    pending: Option<u32>,
}

impl<'a, 'b, PatternMatcher: PipelinePatternMatcher>
    SpecialSegmentIterator<'a, 'b, PatternMatcher>
{
    /// Create a new iterator over [`Segment`] of the [`input`].
    /// This iterator will yield [`Segment`] in order.
    pub fn new(
        input: &'a str,
        pattern_matcher: &'b PatternMatcher,
        normalized: bool,
        encode_special_tokens: bool,
    ) -> Self {
        Self {
            input,
            pattern_matcher,
            normalized,
            encode_special_tokens,
            pending: None,
            offset: 0,
        }
    }
}

impl<'a, 'b, PatternMatcher: PipelinePatternMatcher> Iterator
    for SpecialSegmentIterator<'a, 'b, PatternMatcher>
{
    type Item = Segment<'a>;

    /// Get the next segment of the input.
    fn next(&mut self) -> Option<Self::Item> {
        // take resets the pending option to None
        if let Some(special_token) = self.pending.take() {
            return Some(Segment::SpecialToken(special_token));
        }

        let remaining_input = &self.input[self.offset..];
        if remaining_input.is_empty() {
            // We've processed all the input string, return
            return None;
        }
        if let Some(((start, end), token)) = self.pattern_matcher.extract_next(
            self.input.as_bytes(),
            self.offset,
            self.normalized,
            self.encode_special_tokens,
        ) {
            // `extract_next` positions are absolute in `input`, not relative to `offset`.
            let before_token = &self.input[self.offset..start];
            let input_offset = self.offset;
            self.offset = end;
            if !before_token.is_empty() {
                // The iterator returns segments in order: we need to return the chunk of text and then the special token.
                // Store the special token to return in the next call and return a [`Segment::Text`]
                self.pending = Some(token);
                return Some(Segment::Text {
                    text: before_token,
                    input_offset,
                });
            } else {
                return Some(Segment::SpecialToken(token));
            }
        }
        let input_offset = self.offset;
        self.offset = self.input.len();
        Some(Segment::Text {
            text: remaining_input,
            input_offset,
        })
    }
}

struct TokenizerInner {
    added_vocabulary: BucketAddedVocabulary,
    normalizers: Vec<PipelineNormalizer>,
    pre_tokenizer: PipelinePreTokenizer,
    model: PipelineModel,
    post_processor: PipelinePostProcessor,
    decoder: Option<DecoderRuntime>,
    /// Lowest id owned by the added vocabulary, or `u32::MAX` when there is none.
    /// Allows to skip the added vocabulary lookup if the token id is lower than this value.
    added_id_min: u32,
    /// Which token plays which role (`"eos_token"` -> `"</s>"`), so a `tokenizer.json` can carry
    /// the special-token metadata that used to need a separate `tokenizer_config.json`. Empty
    /// when the config declares none. `BTreeMap` so the writer emits a stable key order.
    role_to_token: BTreeMap<String, String>,
    /// Padding configuration, overridden per call by [`EncodeOptions::padding`].
    padding: Option<PaddingParams>,
    /// Truncation configuration, overridden per call by [`EncodeOptions::truncation`].
    truncation: Option<TruncationParams>,
    /// Pool of scratch buffers. Scratch buffers hold intermediate state (cache, intermediate buffers, etc) required by the tokenization algorithms.
    scratch_pool: ScratchPool,
}

/// Experimental encode-only pipeline built from a [`Tokenizer`]. Runs the same
/// stages over borrowed ranges to avoid the reference path's allocations.
#[derive(Clone)]
pub struct PipelineTokenizer {
    inner: Arc<TokenizerInner>,
}

// comptime verification that PipelineTokenizer is Send + Sync
const _: fn() = || {
    fn assert_send_sync<T: Send + Sync>() {}
    assert_send_sync::<PipelineTokenizer>();
};

impl PipelineTokenizer {
    /// This is the new "constructor" we expose.
    ///
    /// `added_vocabulary` must already have had its tokens replayed *against the concrete model and
    /// in id order*, because `add_tokens` reuses a model id when the token is already in the
    /// vocabulary; doing it later, or out of order, moves ids silently.
    #[allow(clippy::too_many_arguments)]
    pub fn from_parts(
        added_vocabulary: BucketAddedVocabulary,
        normalizers: Vec<PipelineNormalizer>,
        pre_tokenizer: PipelinePreTokenizer,
        model: PipelineModel,
        post_processor: PipelinePostProcessor,
        decoder: Option<DecoderRuntime>,
        role_to_token: BTreeMap<String, String>,
        padding: Option<PaddingParams>,
        truncation: Option<TruncationParams>,
    ) -> Self {
        let added_id_min = added_vocabulary
            .get_added_tokens_decoder()
            .keys()
            .copied()
            .min()
            .unwrap_or(u32::MAX);
        Self {
            inner: Arc::new(TokenizerInner {
                added_vocabulary,
                normalizers,
                pre_tokenizer,
                model,
                post_processor,
                decoder,
                added_id_min,
                role_to_token,
                padding,
                truncation,
                scratch_pool: ScratchPool::new(),
            }),
        }
    }

    pub fn resolve_padding<'a>(
        &'a self,
        padding_override: &'a Override<PaddingParams>,
    ) -> Option<&'a PaddingParams> {
        match padding_override {
            Override::InheritConfig => self.inner.padding.as_ref(),
            Override::Off => None,
            Override::With(params) => Some(params),
        }
    }

    pub fn resolve_truncation<'a>(
        &'a self,
        truncation_override: &'a Override<TruncationParams>,
    ) -> Option<&'a TruncationParams> {
        match truncation_override {
            Override::InheritConfig => self.inner.truncation.as_ref(),
            Override::Off => None,
            Override::With(params) => Some(params),
        }
    }
}
#[derive(Clone)]
pub enum Input {
    Single(String),
    Pair(String, String),
}

#[derive(Clone)]
pub enum Inputs {
    Single(Input),
    Batch(Vec<Input>),
}

impl Inputs {
    fn as_slice(&self) -> &[Input] {
        match self {
            Self::Single(s) => std::slice::from_ref(s),
            Self::Batch(b) => b,
        }
    }

    fn len(&self) -> usize {
        self.as_slice().len()
    }
}

impl<'a> IntoIterator for &'a Inputs {
    type Item = &'a Input;
    type IntoIter = std::slice::Iter<'a, Input>;

    fn into_iter(self) -> Self::IntoIter {
        self.as_slice().iter()
    }
}

impl From<String> for Inputs {
    fn from(s: String) -> Self {
        Self::Single(Input::Single(s))
    }
}

impl From<&str> for Inputs {
    fn from(s: &str) -> Self {
        Self::Single(Input::Single(s.to_owned()))
    }
}

impl From<&String> for Inputs {
    fn from(s: &String) -> Self {
        Self::Single(Input::Single(s.to_owned()))
    }
}

impl From<Vec<String>> for Inputs {
    fn from(b: Vec<String>) -> Self {
        Self::Batch(b.into_iter().map(Input::Single).collect())
    }
}

impl From<&[&str]> for Inputs {
    fn from(b: &[&str]) -> Self {
        Self::Batch(b.iter().map(|s| Input::Single((*s).to_owned())).collect())
    }
}

impl From<Vec<&str>> for Inputs {
    fn from(b: Vec<&str>) -> Self {
        Self::Batch(b.into_iter().map(|s| Input::Single(s.to_owned())).collect())
    }
}

impl From<(String, String)> for Inputs {
    fn from(p: (String, String)) -> Self {
        Self::Single(Input::Pair(p.0, p.1))
    }
}

impl From<(&str, &str)> for Inputs {
    fn from(p: (&str, &str)) -> Self {
        Self::Single(Input::Pair(p.0.to_owned(), p.1.to_owned()))
    }
}

impl From<(&String, &String)> for Inputs {
    fn from(p: (&String, &String)) -> Self {
        Self::Single(Input::Pair(p.0.to_owned(), p.1.to_owned()))
    }
}

impl From<Vec<(String, String)>> for Inputs {
    fn from(b: Vec<(String, String)>) -> Self {
        Self::Batch(b.into_iter().map(|p| Input::Pair(p.0, p.1)).collect())
    }
}

impl From<&[(&str, &str)]> for Inputs {
    fn from(b: &[(&str, &str)]) -> Self {
        Self::Batch(
            b.iter()
                .map(|(s1, s2)| Input::Pair((*s1).to_owned(), (*s2).to_owned()))
                .collect(),
        )
    }
}

enum HandleState {
    Blocking(Enumerate<IntoIter<Result<Encoding>>>),
    #[cfg(feature = "parallelism")]
    Streaming(StreamingIter),
}

pub struct EncodeHandle {
    state: HandleState,
    padding: Option<PaddingParams>,
}

impl EncodeHandle {
    /// Fully computed results, for the serial case
    fn blocking(results: Vec<Result<Encoding>>, padding: Option<PaddingParams>) -> Self {
        Self {
            state: HandleState::Blocking(results.into_iter().enumerate()),
            padding,
        }
    }

    #[cfg(feature = "parallelism")]
    fn streaming(it: StreamingIter, padding: Option<PaddingParams>) -> Self {
        Self {
            state: HandleState::Streaming(it),
            padding,
        }
    }

    fn len(&self) -> usize {
        match &self.state {
            HandleState::Blocking(it) => it.len(),
            #[cfg(feature = "parallelism")]
            HandleState::Streaming(it) => it.len(),
        }
    }
}

impl EncodeHandle {
    /// Wait for all scheduled encoding to finish
    ///
    /// Returns in input order
    pub fn wait(mut self) -> Result<Vec<Encoding>> {
        let padding = self.padding.take();
        // XXX: `Vec::new` does not allocate anything when capacity == 0, so creating empty
        // Encodings should not allocate anything either
        let mut out = vec![Encoding::empty(); self.len()];
        for (seq, res) in self {
            out[seq] = res?;
        }
        if let Some(params) = padding {
            pad_encodings(&mut out, &params)?;
        }
        Ok(out)
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Encoding {
    pub(crate) ids: Vec<PipelineToken>,
    /// `None` if every token has type id 0
    pub(crate) type_ids: Option<Vec<u8>>,
    /// `None` if the encoding is not padded (mask is all ones)
    pub(crate) attention_mask: Option<Vec<u8>>,
}

impl Encoding {
    fn empty() -> Self {
        Self {
            ids: Vec::new(),
            type_ids: None,
            attention_mask: None,
        }
    }

    fn new(ids: Vec<PipelineToken>, type_ids: Option<Vec<u8>>) -> Self {
        debug_assert!(type_ids.as_ref().is_none_or(|t| t.len() == ids.len()));
        Self {
            ids,
            type_ids,
            attention_mask: None,
        }
    }
}

impl Encoding {
    pub fn is_empty(&self) -> bool {
        self.ids.len() == 0
    }

    pub fn len(&self) -> usize {
        self.ids.len()
    }

    pub fn ids(&self) -> &[PipelineToken] {
        &self.ids
    }

    pub fn type_ids(&self) -> Option<&[u8]> {
        self.type_ids.as_deref()
    }

    pub fn attention_mask(&self) -> Option<&[u8]> {
        self.attention_mask.as_deref()
    }
}
/// Iterator yields results in completion order
pub struct HandleIter {
    handle: EncodeHandle,
}

impl Iterator for HandleIter {
    type Item = (usize, Result<Encoding>);

    fn next(&mut self) -> Option<Self::Item> {
        match &mut self.handle.state {
            HandleState::Blocking(it) => it.next(),
            #[cfg(feature = "parallelism")]
            HandleState::Streaming(it) => it.next(),
        }
    }
}

impl IntoIterator for EncodeHandle {
    type Item = (usize, Result<Encoding>);
    type IntoIter = HandleIter;

    fn into_iter(self) -> Self::IntoIter {
        Self::IntoIter { handle: self }
    }
}

impl PipelineTokenizer {
    pub fn get_model(&self) -> &PipelineModel {
        &self.inner.model
    }

    pub fn get_pre_tokenizer(&self) -> &PipelinePreTokenizer {
        &self.inner.pre_tokenizer
    }

    pub fn get_post_processor(&self) -> &PipelinePostProcessor {
        &self.inner.post_processor
    }

    /// The whole flattened normalizer chain, in the order it runs.
    ///
    /// This is for a writer, which needs the members themselves. A config `Sequence` was
    /// flattened on the way in, so what comes back is the concatenation, not the nesting.
    pub fn get_normalizers(&self) -> &[PipelineNormalizer] {
        &self.inner.normalizers
    }

    /// The decoder, if the config declared one.
    pub fn get_decoder(&self) -> Option<&DecoderRuntime> {
        self.inner.decoder.as_ref()
    }

    /// The added vocabulary, whose `get_added_tokens_decoder` is the `added_tokens` array.
    pub fn get_added_vocabulary(&self) -> &BucketAddedVocabulary {
        &self.inner.added_vocabulary
    }

    /// Which token plays which role, as the config declared it. Empty when it declared none.
    pub fn get_role_to_token(&self) -> &BTreeMap<String, String> {
        &self.inner.role_to_token
    }

    /// The token a role points at, e.g. `get_token_for_role("eos_token")`.
    pub fn get_token_for_role(&self, role: &str) -> Option<&str> {
        self.inner.role_to_token.get(role).map(String::as_str)
    }

    pub fn get_padding(&self) -> Option<&PaddingParams> {
        self.inner.padding.as_ref()
    }

    pub fn get_truncation(&self) -> Option<&TruncationParams> {
        self.inner.truncation.as_ref()
    }

    /// Encode `input` into token ids.
    ///
    /// Special tokens are matched in two passes:
    ///  1. on the raw input,
    ///  2. then on each segment after normalization
    ///
    /// This way, special / added tokens declared on raw or normalized text are both caught.
    /// The remaining text is pre-tokenized and run through the model span by span.
    pub fn encode(&self, inputs: impl Into<Inputs>, options: &EncodeOptions) -> EncodeHandle {
        let inputs = inputs.into();
        assert!(
            inputs.len() < usize::MAX,
            "we use usize::MAX as a sentinel value for the completion queue, we don't support batches larger than that"
        );
        #[cfg(not(feature = "parallelism"))]
        return EncodeHandle::blocking(
            self.encode_serial(inputs, options),
            self.resolve_padding(&options.padding).cloned(),
        );

        #[cfg(feature = "parallelism")]
        parallel::encode(self, inputs, options)
    }

    fn encode_serial(&self, inputs: Inputs, options: &EncodeOptions) -> Vec<Result<Encoding>> {
        let mut scratch = self.inner.scratch_pool.get(&self.inner.model);
        match inputs {
            Inputs::Single(input) => {
                vec![self.encode_one(input, options, &mut scratch)]
            }
            Inputs::Batch(batch) => {
                let mut output = Vec::with_capacity(batch.len());
                for input in batch {
                    output.push(self.encode_one(input, options, &mut scratch));
                }
                output
            }
        }
    }

    fn encode_one(
        &self,
        input: Input,
        options: &EncodeOptions,
        scratch: &mut EncodeScratch,
    ) -> Result<Encoding> {
        match input {
            Input::Single(seq) => {
                let toks = self.encode_sequence_with(&seq, 0, options, scratch)?;
                Ok(self.post_process(toks, None, options)?)
            }
            // Each side of a pair is a sequence of its own, so both start at offset 0.
            Input::Pair(s1, s2) => {
                let a = self.encode_sequence_with(&s1, 0, options, scratch)?;
                let b = self.encode_sequence_with(&s2, 0, options, scratch)?;
                Ok(self.post_process(a, Some(b), options)?)
            }
        }
    }

    /// Decode a slice of token ids to a Vec of the tokens' string representation
    pub fn decode_tokens(&self, ids: &[u32], skip_special_tokens: bool) -> Vec<String> {
        ids.iter()
            .filter_map(|&id| {
                if id >= self.inner.added_id_min {
                    self.inner
                        .added_vocabulary
                        .simple_id_to_token(id)
                        .or_else(|| self.inner.model.id_to_token(id))
                        .filter(|token| {
                            !skip_special_tokens
                                || !self.inner.added_vocabulary.is_special_token(token)
                        })
                } else {
                    self.inner.model.id_to_token(id)
                }
            })
            .collect()
    }

    /// Pick the template the input shape calls for and let it add the specials.
    ///
    /// Two instantiations, chosen here, so `add_special_tokens` is a constant inside.
    fn post_process(
        &self,
        s1: Vec<PipelineToken>,
        s2: Option<Vec<PipelineToken>>,
        options: &EncodeOptions,
    ) -> Result<Encoding> {
        let pp = &self.inner.post_processor;
        let template = if s2.is_some() { &pp.pair } else { &pp.single };
        let num_added_specials = if options.add_special_tokens {
            template.n_special()
        } else {
            0
        };
        let truncation = self.resolve_truncation(&options.truncation);
        let (s1, s2) = truncate_pair(s1, s2, truncation, num_added_specials)?;
        Ok(if options.add_special_tokens {
            template.post_process::<true>(s1, s2)
        } else {
            template.post_process::<false>(s1, s2)
        })
    }

    /// Encode one sequence, appending its ids to `output`.
    ///
    /// Takes the buffer rather than returning one, so a caller that already owns somewhere to put
    /// the ids -- [`Self::encode_into`] -- pays neither an allocation nor a copy for them.
    ///
    /// `offset` is where `input` starts in its sequence: the parallel encoder hands over slices of
    /// a longer sequence, and `PrependBehavior::First` needs to know which slice opens it.
    fn encode_sequence_into(
        &self,
        input: &str,
        offset: usize,
        options: &EncodeOptions,
        scratch: &mut EncodeScratch,
        output: &mut Vec<PipelineToken>,
    ) -> Result<()> {
        // First, we extract all special tokens from the non-normalized input
        for segment in SpecialSegmentIterator::new(
            input,
            &self.inner.added_vocabulary,
            false,
            options.encode_special_tokens,
        ) {
            match segment {
                Segment::SpecialToken(token) => {
                    output.push(PipelineToken::from(token));
                }
                Segment::Text {
                    text: chunk,
                    input_offset,
                } => {
                    let normalized =
                        normalize_all(&self.inner.normalizers, chunk, offset + input_offset)?;

                    // Extract special tokens from the normalized input
                    for segment in SpecialSegmentIterator::new(
                        &normalized,
                        &self.inner.added_vocabulary,
                        true,
                        options.encode_special_tokens,
                    ) {
                        match segment {
                            Segment::SpecialToken(token) => {
                                output.push(PipelineToken::from(token));
                            }
                            Segment::Text {
                                text: normalized_chunk,
                                ..
                            } => {
                                // A [`Span`] holds `u32` offsets, which breaks the `PreTokenizer` contract the
                                // `str::get_unchecked` below relies on.
                                // Normalization can grow the text (`Metaspace` widens every space to a 3-byte delimiter),
                                // which is why this is checked here and not on `input`.
                                if normalized_chunk.len() > u32::MAX as usize {
                                    return Err(format!(
                                        "sequence too long to pre-tokenize: {} bytes after normalization, the limit is {}",
                                        normalized_chunk.len(),
                                        u32::MAX
                                    )
                                    .into());
                                }
                                // Pre-tokenize the chunk of normalized text
                                let EncodeScratch {
                                    model: model_scratch,
                                    pre_tokens,
                                    split: pre_tokenizer_scratch,
                                } = &mut *scratch;
                                pre_tokens.clear();
                                self.inner.pre_tokenizer.pre_tokenize(
                                    normalized_chunk,
                                    pre_tokenizer_scratch,
                                    pre_tokens,
                                )?;
                                output.reserve(pre_tokens.len());
                                #[cfg(debug_assertions)]
                                for pre_token in pre_tokens.iter() {
                                    let range = pre_token.range();
                                    debug_assert!(
                                        range.start <= range.end
                                            && normalized_chunk.is_char_boundary(range.start)
                                            && normalized_chunk.is_char_boundary(range.end),
                                        "{:?} broke the PreTokenizer contract: emitted {pre_token:?} for {normalized_chunk:?}",
                                        self.inner.pre_tokenizer,
                                    );
                                }
                                // The whole span list at once; see Model::tokenize_spans.
                                // SAFETY: `PreTokenizer` guarantees every span is a valid range of
                                // `normalized_chunk`, which is what lets the model slice it unchecked.
                                self.inner.model.tokenize_spans(
                                    normalized_chunk,
                                    pre_tokens,
                                    model_scratch,
                                    output,
                                )?;
                            }
                        }
                    }
                }
            };
        }
        Ok(())
    }

    /// [`Self::encode_sequence_into`] into a fresh buffer, for the callers that want one back.
    fn encode_sequence_with(
        &self,
        input: &str,
        offset: usize,
        options: &EncodeOptions,
        scratch: &mut EncodeScratch,
    ) -> Result<Vec<PipelineToken>> {
        let mut output = Vec::with_capacity(input.len() / 4);
        self.encode_sequence_into(input, offset, options, scratch, &mut output)?;
        Ok(output)
    }

    /// Encode `input`, appending its ids to `out`.
    ///
    /// The entry point that allocates nothing per call: no `Encoding`, no `Vec<Encoding>` from the
    /// handle, and no copy out of either. [`Self::encode`] is this plus those wrappers, and an
    /// encode-only caller in a loop -- a server, a benchmark -- wants this one.
    ///
    /// Falls back to the general path when the post-processor actually has something to add
    /// around the sequence, since that has to assemble a whole `Encoding` anyway.
    pub fn encode_into(
        &self,
        input: &str,
        options: &EncodeOptions,
        out: &mut Vec<PipelineToken>,
    ) -> Result<()> {
        let mut scratch = self.inner.scratch_pool.get(&self.inner.model);
        let template = &self.inner.post_processor.single;
        let reproduces_sequence = self.resolve_truncation(&options.truncation).is_none()
            && !template.has_type_ids()
            && (!options.add_special_tokens || template.n_special() == 0);
        if reproduces_sequence {
            return self.encode_sequence_into(input, 0, options, &mut scratch, out);
        }
        let encoding = self.encode_one(Input::Single(input.to_owned()), options, &mut scratch)?;
        out.extend_from_slice(encoding.ids());
        Ok(())
    }

    /// Decode token ids back to a `String`.
    ///
    /// Two routes, picked by what the model's vocab store actually holds:
    ///
    /// * **byte-level BPE** -- [`byte_level::transform_vocab`] already replaced every entry with
    ///   its decoded raw bytes when the model was built, so decoding is a concatenation of
    ///   borrowed slices. See [`Self::decode_byte_level`].
    /// * **everything else** -- the store holds the token strings as written, so the configured
    ///   [`DecoderWrapper`] still has to invert whatever the pre-tokenizer did. Same shape as the
    ///   released `Tokenizer::decode`.
    ///
    /// [`byte_level::transform_vocab`]: crate::utils::byte_level::transform_vocab
    pub fn decode(&self, ids: &[u32], skip_special_tokens: bool) -> Result<String> {
        // Irrefutable in a `bpe`-only build, where `PipelineModel` has exactly one variant, and
        // nightly lints a leading irrefutable pattern in a let chain. Nesting the `if` instead
        // would trade this for `collapsible_if` on every build that has more than one model.
        #[allow(irrefutable_let_patterns)]
        if let PipelineModel::BPE(bpe) = &self.inner.model
            && bpe.is_byte_level()
        {
            return Ok(self.decode_byte_level(bpe, ids, skip_special_tokens));
        }
        let tokens = self.decode_tokens(ids, skip_special_tokens);
        match &self.inner.decoder {
            Some(decoder) => decoder.decode(tokens),
            None => Ok(tokens.join(" ")),
        }
    }

    /// Decode for a byte-level BPE, whose vocab entries are already decoded raw bytes.
    fn decode_byte_level(
        &self,
        bpe: &PipelineBPE,
        ids: &[u32],
        skip_special_tokens: bool,
    ) -> String {
        // Byte-level tokens average ~4 bytes
        let mut out: Vec<u8> = Vec::with_capacity(ids.len() * 4);
        for &id in ids {
            if id >= self.inner.added_id_min
                && let Some(token) = self.inner.added_vocabulary.simple_id_to_token(id)
            {
                if !skip_special_tokens || !self.inner.added_vocabulary.is_special_token(&token) {
                    out.extend_from_slice(token.as_bytes());
                }
                continue;
            }
            if let Some(bytes) = bpe.id_to_token_bytes(id) {
                out.extend_from_slice(bytes);
            }
        }
        match String::from_utf8(out) {
            Ok(decoded) => decoded,
            Err(invalid) => String::from_utf8_lossy(invalid.as_bytes()).into_owned(),
        }
    }

    /// Decode several id sequences at once, one `String` per input. Mirrors the
    /// released `decode_batch`; sequential (KISS), behavior-identical to a
    /// parallel map, since each [`decode`](Self::decode) is independent.
    pub fn decode_batch(
        &self,
        sentences: &[&[u32]],
        skip_special_tokens: bool,
    ) -> Result<Vec<String>> {
        sentences
            .iter()
            .map(|ids| self.decode(ids, skip_special_tokens))
            .collect()
    }

    /// Incremental decode: feed ids one at a time via [`PipelineDecodeStream::step`].
    /// Same prefix-tracking scheme as the released `DecodeStream`, built on
    /// [`decode`](Self::decode), so it is correct exactly where `decode` is.
    pub fn decode_stream(&self, skip_special_tokens: bool) -> PipelineDecodeStream<'_> {
        PipelineDecodeStream {
            tokenizer: self,
            ids: Vec::new(),
            skip_special_tokens,
            prefix: String::new(),
            prefix_index: 0,
        }
    }
}

/// Streaming decoder over a [`PipelineTokenizer`]; see [`PipelineTokenizer::decode_stream`].
pub struct PipelineDecodeStream<'tok> {
    tokenizer: &'tok PipelineTokenizer,
    ids: Vec<u32>,
    skip_special_tokens: bool,
    prefix: String,
    prefix_index: usize,
}

impl PipelineDecodeStream<'_> {
    /// Push one id and return the text it completes, or `None` while a multi-token
    /// (or multi-byte) unit is still forming. Ids past the emitted prefix are kept
    /// as decode context so cross-token decoders (byte-level, WordPiece `##`, …)
    /// see the same input a one-shot [`decode`](PipelineTokenizer::decode) would.
    pub fn step(&mut self, id: u32) -> Result<Option<String>> {
        if self.prefix.is_empty() && !self.ids.is_empty() {
            let new_prefix = self.tokenizer.decode(&self.ids, self.skip_special_tokens)?;
            if !new_prefix.ends_with('\u{fffd}') {
                self.prefix = new_prefix;
                self.prefix_index = self.ids.len();
            }
        }

        self.ids.push(id);
        let string = self.tokenizer.decode(&self.ids, self.skip_special_tokens)?;
        if string.len() > self.prefix.len() && !string.ends_with('\u{fffd}') {
            if !string.starts_with(&self.prefix) {
                return Err(format!(
                    "decode stream: {string:?} does not extend prefix {:?}",
                    self.prefix
                )
                .into());
            }
            let new_text = string[self.prefix.len()..].to_string();
            let new_prefix_index = self.ids.len() - self.prefix_index;
            self.ids = self.ids.split_off(self.prefix_index);
            self.prefix = self.tokenizer.decode(&self.ids, self.skip_special_tokens)?;
            self.prefix_index = new_prefix_index;
            Ok(Some(new_text))
        } else {
            Ok(None)
        }
    }
}

pub trait Model {
    type Scratch: ModelScratch;

    fn tokenize_pipeline(
        &self,
        sequence: &str,
        scratch: &mut Self::Scratch,
        output: &mut Vec<PipelineToken>,
    ) -> Result<()>;

    /// Every pre-token of a chunk in one call.
    ///
    /// The pipeline has the whole span list before the model runs, so handing them over one at a
    /// time bought nothing and cost a virtual call, a slice, a `Result` and an output capacity
    /// check per pre-token -- on English that is one round trip per ~5 bytes.
    ///
    /// The default is the loop it replaces, so a model only overrides this if it has per-chunk
    /// work to hoist out of the loop.
    fn tokenize_spans(
        &self,
        chunk: &str,
        spans: &[Span],
        scratch: &mut Self::Scratch,
        output: &mut Vec<PipelineToken>,
    ) -> Result<()> {
        for span in spans {
            self.tokenize_pipeline(&chunk[span.range()], scratch, output)?;
        }
        Ok(())
    }

    fn init_scratch(&self) -> Self::Scratch;
}

#[allow(
    clippy::large_enum_variant,
    reason = "PipelineBPE holds a 1kB byte -> id lookup table"
)]
pub enum PipelineModel {
    BPE(PipelineBPE),
    #[cfg(feature = "unigram")]
    Unigram(Unigram),
    #[cfg(feature = "wordlevel")]
    WordLevel(WordLevel),
    #[cfg(feature = "wordpiece")]
    WordPiece(PipelineWordPiece),
}

impl PipelineModel {
    /// `id -> token` used by [`PipelineTokenizer::decode`]
    pub fn id_to_token(&self, id: u32) -> Option<String> {
        match self {
            Self::BPE(model) => model.id_to_token(id),
            #[cfg(feature = "unigram")]
            Self::Unigram(model) => model.id_to_token(id),
            #[cfg(feature = "wordlevel")]
            Self::WordLevel(model) => model.id_to_token(id),
            #[cfg(feature = "wordpiece")]
            Self::WordPiece(model) => model.id_to_token(id),
        }
    }
}

/// A set of buffers and other state the model needs to encode efficiently,
/// reused among calls to [`PipelineTokenizer::encode`].
///
/// Each model gets its own variant.
impl Model for PipelineModel {
    type Scratch = PipelineModelScratch;

    fn tokenize_pipeline(
        &self,
        sequence: &str,
        scratch: &mut Self::Scratch,
        output: &mut Vec<PipelineToken>,
    ) -> Result<()> {
        match (self, scratch) {
            (Self::BPE(model), PipelineModelScratch::BPE(scratch)) => {
                model.tokenize_pipeline(sequence, scratch, output)
            }
            #[cfg(feature = "unigram")]
            (Self::Unigram(model), PipelineModelScratch::Unigram(scratch)) => {
                model.tokenize_pipeline(sequence, scratch, output)
            }
            #[cfg(feature = "wordlevel")]
            (Self::WordLevel(model), PipelineModelScratch::WordLevel(scratch)) => {
                model.tokenize_pipeline(sequence, scratch, output)
            }
            #[cfg(feature = "wordpiece")]
            (Self::WordPiece(model), PipelineModelScratch::WordPiece(scratch)) => {
                model.tokenize_pipeline(sequence, scratch, output)
            }
            _ => unreachable!(),
        }
    }

    fn tokenize_spans(
        &self,
        chunk: &str,
        spans: &[Span],
        scratch: &mut Self::Scratch,
        output: &mut Vec<PipelineToken>,
    ) -> Result<()> {
        match (self, scratch) {
            (Self::BPE(model), PipelineModelScratch::BPE(scratch)) => {
                model.tokenize_spans(chunk, spans, scratch, output)
            }
            #[cfg(feature = "unigram")]
            (Self::Unigram(model), PipelineModelScratch::Unigram(scratch)) => {
                model.tokenize_spans(chunk, spans, scratch, output)
            }
            #[cfg(feature = "wordlevel")]
            (Self::WordLevel(model), PipelineModelScratch::WordLevel(scratch)) => {
                model.tokenize_spans(chunk, spans, scratch, output)
            }
            #[cfg(feature = "wordpiece")]
            (Self::WordPiece(model), PipelineModelScratch::WordPiece(scratch)) => {
                model.tokenize_spans(chunk, spans, scratch, output)
            }
            _ => unreachable!(),
        }
    }

    fn init_scratch(&self) -> Self::Scratch {
        match self {
            Self::BPE(bpe) => PipelineModelScratch::BPE(bpe.init_scratch()),
            #[cfg(feature = "wordlevel")]
            Self::WordLevel(_) => Self::Scratch::WordLevel(()),
            #[cfg(feature = "wordpiece")]
            Self::WordPiece(wordpiece) => Self::Scratch::WordPiece(wordpiece.init_scratch()),
            #[cfg(feature = "unigram")]
            Self::Unigram(unigram) => Self::Scratch::Unigram(unigram.init_scratch()),
        }
    }
}

#[derive(Default)]
pub enum PipelineModelScratch {
    BPE(BpeScratch),
    #[cfg(feature = "wordlevel")]
    WordLevel(()),
    #[cfg(feature = "wordpiece")]
    WordPiece(WordPieceScratch),
    #[cfg(feature = "unigram")]
    Unigram(UnigramScratch),
    /// We need a default value to be able to use [`mem::take`] in [`ScratchGuard::drop`]
    #[default]
    None,
}

impl ModelScratch for PipelineModelScratch {}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::PaddingStrategy;
    use crate::tokenizer::{TruncationDirection, TruncationStrategy};
    use crate::utils::truncation::TruncationError;
    use crate::vocab::bucket_added_vocabulary::AddedToken;

    struct FixedMatcher(Vec<((usize, usize), u32)>);
    impl PipelinePatternMatcher for FixedMatcher {
        fn extract_next(
            &self,
            _bytes: &[u8],
            search_offset: usize,
            _normalized: bool,
            _encode_special_tokens: bool,
        ) -> Option<((usize, usize), u32)> {
            self.0
                .iter()
                .find(|((start, _), _)| *start >= search_offset)
                .copied()
        }
    }

    #[test]
    fn segment_iterator_yields_text_and_specials_in_order() {
        let input = "aa<s>bb<s>cc";
        let matcher = FixedMatcher(vec![((2, 5), 0), ((7, 10), 1)]);

        let segments: Vec<_> = SpecialSegmentIterator::new(input, &matcher, false, false)
            .map(|segment| match segment {
                Segment::Text { text, .. } => (Some(text), None),
                Segment::SpecialToken(id) => (None, Some(id)),
            })
            .collect();

        assert_eq!(
            segments,
            vec![
                (Some("aa"), None),
                (None, Some(0)),
                (Some("bb"), None),
                (None, Some(1)),
                (Some("cc"), None),
            ]
        );
    }

    #[test]
    fn padding_defaults_to_none() {
        let pipeline = hello_pipeline();

        assert!(pipeline.get_padding().is_none());
    }

    #[test]
    fn from_parts_padding_is_visible_through_get_padding() {
        let pipeline = hello_pipeline_with_padding(PaddingParams {
            pad_id: 42,
            ..PaddingParams::default()
        });

        assert_eq!(pipeline.get_padding().unwrap().pad_id, 42);
    }

    // "hhello" tokenizes to 2 ids and "hello" to 1 (both merge down to `hello`, but the leading
    // "h" in "hhello" has nothing left to merge with once "hello" is taken), which is exactly the
    // uneven batch padding exists for.
    #[test]
    fn wait_leaves_a_batch_unpadded_with_no_padding_config() {
        let pipeline = hello_pipeline();

        let encodings = pipeline
            .encode(vec!["hhello", "hello"], &EncodeOptions::no_specials())
            .wait()
            .unwrap();

        assert_eq!(encodings[0].len(), 2);
        assert_eq!(encodings[1].len(), 1);
    }

    #[test]
    fn wait_applies_the_tokenizers_configured_padding() {
        let pipeline = hello_pipeline_with_padding(PaddingParams {
            strategy: PaddingStrategy::BatchLongest,
            ..PaddingParams::default()
        });

        let encodings = pipeline
            .encode(vec!["hhello", "hello"], &EncodeOptions::no_specials())
            .wait()
            .unwrap();

        assert_eq!(encodings[0].len(), 2);
        assert_eq!(encodings[1].len(), 2);
    }

    #[test]
    fn override_with_replaces_the_tokenizers_configured_padding() {
        let pipeline = hello_pipeline_with_padding(PaddingParams {
            strategy: PaddingStrategy::BatchLongest,
            ..PaddingParams::default()
        });
        let options = EncodeOptions {
            padding: Override::With(PaddingParams {
                strategy: PaddingStrategy::Fixed(5),
                ..PaddingParams::default()
            }),
            ..EncodeOptions::no_specials()
        };

        let encodings = pipeline
            .encode(vec!["hhello", "hello"], &options)
            .wait()
            .unwrap();

        assert!(encodings.iter().all(|e| e.len() == 5));
    }

    // `lol` has no merge in the hello BPE, so it comes back as `l o l` when the model sees it and
    // as its added id when it is carved out first.
    #[test]
    fn encode_special_tokens_sends_the_special_through_the_model() {
        let pipeline = hello_pipeline_with_special("lol");
        let carved = EncodeOptions::no_specials();
        let encoded = EncodeOptions {
            encode_special_tokens: true,
            ..EncodeOptions::no_specials()
        };

        let ids = |options: &EncodeOptions| -> Vec<u32> {
            let encodings = pipeline.encode("lolhello", options).wait().unwrap();
            encodings[0].ids().iter().map(|t| t.id()).collect()
        };

        assert_eq!(ids(&carved), vec![8, 7]);
        assert_eq!(ids(&encoded), vec![2, 3, 2, 7]);
    }

    #[test]
    fn override_off_turns_off_the_tokenizers_configured_padding() {
        let pipeline = hello_pipeline_with_padding(PaddingParams {
            strategy: PaddingStrategy::BatchLongest,
            ..PaddingParams::default()
        });
        let options = EncodeOptions {
            padding: Override::Off,
            ..EncodeOptions::no_specials()
        };

        let encodings = pipeline
            .encode(vec!["hhello", "hello"], &options)
            .wait()
            .unwrap();

        assert_eq!(encodings[0].len(), 2);
        assert_eq!(encodings[1].len(), 1);
    }

    // "hhhhhhello" encodes to five lone `h` and one `hello`: six ids, enough for a cut at 2 and a
    // pad to 8 to each leave a visible trace.
    const SIX_TOKENS: &str = "hhhhhhello";
    const PAD: u32 = 9;

    fn truncate_to(max_length: usize) -> TruncationParams {
        TruncationParams {
            max_length,
            ..TruncationParams::default()
        }
    }

    fn pad_to(length: usize) -> PaddingParams {
        PaddingParams {
            strategy: PaddingStrategy::Fixed(length),
            pad_id: PAD,
            ..PaddingParams::default()
        }
    }

    fn encode_six_tokens(pipeline: &PipelineTokenizer, options: &EncodeOptions) -> Encoding {
        pipeline
            .encode(SIX_TOKENS, options)
            .wait()
            .unwrap()
            .remove(0)
    }

    #[test]
    fn override_with_replaces_the_tokenizers_configured_truncation() {
        let pipeline = hello_pipeline_with_truncation(truncate_to(5));
        let options = EncodeOptions {
            truncation: Override::With(truncate_to(2)),
            ..EncodeOptions::default()
        };

        assert_eq!(ids(&encode_six_tokens(&pipeline, &options)), [0, 0]);
    }

    #[test]
    fn override_off_turns_off_the_tokenizers_configured_truncation() {
        let pipeline = hello_pipeline_with_truncation(truncate_to(2));
        let options = EncodeOptions {
            truncation: Override::Off,
            ..EncodeOptions::default()
        };

        assert_eq!(
            ids(&encode_six_tokens(&pipeline, &options)),
            [0, 0, 0, 0, 0, 7]
        );
    }

    // Truncating to 2 and then padding to 8 gives [h, h] and six pads. Padding first would leave the
    // six ids alone, and the cut would then give [h, h] and nothing else.
    const TRUNCATED_THEN_PADDED: [u32; 8] = [0, 0, PAD, PAD, PAD, PAD, PAD, PAD];

    #[test]
    fn configured_truncation_runs_before_configured_padding() {
        let pipeline = hello_pipeline_with(
            PipelinePostProcessor::default(),
            Some(pad_to(8)),
            Some(truncate_to(2)),
        );

        let encoding = encode_six_tokens(&pipeline, &EncodeOptions::default());

        assert_eq!(ids(&encoding), TRUNCATED_THEN_PADDED);
        assert_eq!(
            encoding.attention_mask().unwrap(),
            [1u8, 1, 0, 0, 0, 0, 0, 0]
        );
    }

    #[test]
    fn overridden_truncation_runs_before_overridden_padding() {
        let pipeline = hello_pipeline();
        let options = EncodeOptions {
            padding: Override::With(pad_to(8)),
            truncation: Override::With(truncate_to(2)),
            ..EncodeOptions::default()
        };

        let encoding = encode_six_tokens(&pipeline, &options);

        assert_eq!(ids(&encoding), TRUNCATED_THEN_PADDED);
        assert_eq!(
            encoding.attention_mask().unwrap(),
            [1u8, 1, 0, 0, 0, 0, 0, 0]
        );
    }

    #[test]
    fn overridden_truncation_keeps_the_configured_padding() {
        let pipeline = hello_pipeline_with_padding(pad_to(8));
        let options = EncodeOptions {
            truncation: Override::With(truncate_to(2)),
            ..EncodeOptions::default()
        };

        assert_eq!(
            ids(&encode_six_tokens(&pipeline, &options)),
            TRUNCATED_THEN_PADDED
        );
    }

    #[test]
    fn overridden_padding_keeps_the_configured_truncation() {
        let pipeline = hello_pipeline_with_truncation(truncate_to(2));
        let options = EncodeOptions {
            padding: Override::With(pad_to(8)),
            ..EncodeOptions::default()
        };

        assert_eq!(
            ids(&encode_six_tokens(&pipeline, &options)),
            TRUNCATED_THEN_PADDED
        );
    }

    #[test]
    fn padding_off_keeps_the_configured_truncation() {
        let pipeline = hello_pipeline_with(
            PipelinePostProcessor::default(),
            Some(pad_to(8)),
            Some(truncate_to(2)),
        );
        let options = EncodeOptions {
            padding: Override::Off,
            ..EncodeOptions::default()
        };

        assert_eq!(ids(&encode_six_tokens(&pipeline, &options)), [0, 0]);
    }

    #[test]
    fn truncation_off_keeps_the_configured_padding() {
        let pipeline = hello_pipeline_with(
            PipelinePostProcessor::default(),
            Some(pad_to(8)),
            Some(truncate_to(2)),
        );
        let options = EncodeOptions {
            truncation: Override::Off,
            ..EncodeOptions::default()
        };

        assert_eq!(
            ids(&encode_six_tokens(&pipeline, &options)),
            [0, 0, 0, 0, 0, 7, PAD, PAD]
        );
    }

    #[test]
    fn test_truncate_with_specials() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(5, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, 1, 2, 3, SEP]);
    }

    // Released 0.23.1 subtracts the specials from `max_length` only when it is about to add them
    // (`add_special_tokens && n_added_tokens > 0`, tokenizer/mod.rs:1243), so a caller that asks
    // for no specials gets a full `max_length` of sequence tokens.
    #[test]
    fn test_no_specials_added() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(5, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::no_specials())
            .unwrap();

        assert_eq!(ids(&encoding), [1, 2, 3, 4, 5]);
    }

    #[test]
    fn test_fits() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(5, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(tokens(1..=3), None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, 1, 2, 3, SEP]);
    }

    #[test]
    fn test_no_truncation() {
        let pipeline = pipeline_with(bert_post_processor(), None);

        let encoding = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, 1, 2, 3, 4, 5, 6, 7, 8, SEP]);
    }

    #[test]
    fn test_truncate_left() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            Some(TruncationParams {
                max_length: 5,
                direction: TruncationDirection::Left,
                ..TruncationParams::default()
            }),
        );

        let encoding = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, 6, 7, 8, SEP]);
    }

    #[test]
    fn test_pair_specials() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(8, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(
                tokens(1..=4),
                Some(tokens(11..=14)),
                &EncodeOptions::default(),
            )
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, 1, 2, SEP, 11, 12, 13, SEP]);
        assert_eq!(encoding.type_ids().unwrap(), [0, 0, 0, 0, 1, 1, 1, 1]);
    }

    #[test]
    fn test_only_second() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(8, TruncationStrategy::OnlySecond),
        );

        let encoding = pipeline
            .post_process(
                tokens(1..=4),
                Some(tokens(11..=14)),
                &EncodeOptions::default(),
            )
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, 1, 2, 3, 4, SEP, 11, SEP]);
        assert_eq!(encoding.type_ids().unwrap(), [0, 0, 0, 0, 0, 0, 1, 1]);
    }

    // `OnlySecond` names the sequence to cut, so a lone sequence has nothing to cut. The error has
    // to come back out of `post_process` rather than the first sequence being cut instead.
    #[test]
    fn test_only_second_no_pair() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(5, TruncationStrategy::OnlySecond),
        );

        let err = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::default())
            .err()
            .unwrap();

        assert!(matches!(
            err.downcast_ref::<TruncationError>(),
            Some(TruncationError::SecondSequenceNotProvided)
        ));
    }

    // `max_length` 1 cannot hold `[CLS] [SEP]`. The sequence goes and the specials stay, so the
    // encoding comes back longer than `max_length`. There is no upstream behaviour to match:
    // released 0.23.1 computes `max_length - n_added_tokens` unguarded (tokenizer/mod.rs:1245).
    #[test]
    fn test_max_length_below_specials() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(1, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, SEP]);
    }

    // Same case for a pair: the pair template places sequence B, so an emptied B still has to be
    // there for the template to lay out.
    #[test]
    fn test_max_length_below_specials_pair() {
        let pipeline = pipeline_with(
            bert_post_processor(),
            truncation(1, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(
                tokens(1..=4),
                Some(tokens(11..=14)),
                &EncodeOptions::default(),
            )
            .unwrap();

        assert_eq!(ids(&encoding), [CLS, SEP, SEP]);
        assert_eq!(encoding.type_ids().unwrap(), [0, 0, 1]);
    }

    // A template that adds nothing takes the fast path, which hands the sequence buffer straight
    // back. It has to be the truncated buffer.
    #[test]
    fn test_empty_template() {
        let pipeline = pipeline_with(
            PipelinePostProcessor::default(),
            truncation(3, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(ids(&encoding), [1, 2, 3]);
    }

    // A single template that retags its sequence carries type ids, which rules out the fast path.
    // This is truncation reaching the template with no specials in the way.
    #[test]
    fn test_template_type_ids() {
        let pipeline = pipeline_with(
            PipelinePostProcessor {
                single: Template {
                    a_type_id: 1,
                    ..Template::default()
                },
                pair: Template {
                    b_type_id: Some(1),
                    ..Template::default()
                },
            },
            truncation(3, TruncationStrategy::LongestFirst),
        );

        let encoding = pipeline
            .post_process(tokens(1..=8), None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(ids(&encoding), [1, 2, 3]);
        assert_eq!(encoding.type_ids().unwrap(), [1, 1, 1]);
    }

    // The fast path returns the sequence buffer itself. A copy would be a silent regression that
    // no assertion on the ids can catch.
    #[test]
    fn test_fast_path_buffer() {
        let pipeline = pipeline_with(PipelinePostProcessor::default(), None);
        let sequence = tokens(1..=8);
        let address = sequence.as_ptr();

        let encoding = pipeline
            .post_process(sequence, None, &EncodeOptions::default())
            .unwrap();

        assert_eq!(encoding.ids().as_ptr(), address);
    }

    // `encode_into` has a shortcut of its own for a template that adds nothing, and it skips
    // `post_process`, which is where truncation happens. Whatever route it takes, it has to agree
    // with `encode`.
    #[test]
    fn test_encode_into() {
        let pipeline = pipeline_with(
            PipelinePostProcessor::default(),
            truncation(2, TruncationStrategy::LongestFirst),
        );
        let mut out = Vec::new();

        pipeline
            .encode_into("hhello hhello", &EncodeOptions::default(), &mut out)
            .unwrap();

        let encoded = pipeline
            .encode(vec!["hhello hhello"], &EncodeOptions::default())
            .wait()
            .unwrap();
        assert_eq!(out.len(), 2);
        assert_eq!(out, encoded[0].ids());
    }

    const CLS: u32 = 101;
    const SEP: u32 = 102;

    fn tokens(sequence_ids: impl IntoIterator<Item = u32>) -> Vec<PipelineToken> {
        sequence_ids.into_iter().map(PipelineToken::from).collect()
    }

    fn ids(encoding: &Encoding) -> Vec<u32> {
        encoding.ids().iter().copied().map(u32::from).collect()
    }

    /// `[CLS] $A [SEP]` and `[CLS] $A [SEP] $B:1 [SEP]:1`, the arrangement BERT's config declares.
    fn bert_post_processor() -> PipelinePostProcessor {
        PipelinePostProcessor {
            single: Template {
                prefix: Box::new([(CLS.into(), 0)]),
                suffix: Box::new([(SEP.into(), 0)]),
                ..Template::default()
            },
            pair: Template {
                prefix: Box::new([(CLS.into(), 0)]),
                infix: Box::new([(SEP.into(), 0)]),
                suffix: Box::new([(SEP.into(), 1)]),
                b_type_id: Some(1),
                ..Template::default()
            },
        }
    }

    fn truncation(max_length: usize, strategy: TruncationStrategy) -> Option<TruncationParams> {
        Some(TruncationParams {
            max_length,
            strategy,
            ..TruncationParams::default()
        })
    }

    fn pipeline_with(
        post_processor: PipelinePostProcessor,
        truncation: Option<TruncationParams>,
    ) -> PipelineTokenizer {
        hello_pipeline_with(post_processor, None, truncation)
    }

    fn hello_pipeline_with(
        post_processor: PipelinePostProcessor,
        padding: Option<PaddingParams>,
        truncation: Option<TruncationParams>,
    ) -> PipelineTokenizer {
        PipelineTokenizer::from_parts(
            BucketAddedVocabulary::new(),
            Vec::new(),
            PipelinePreTokenizer::None,
            PipelineModel::BPE(hello_bpe()),
            post_processor,
            None,
            Default::default(),
            padding,
            truncation,
        )
    }

    #[test]
    fn decode_tokens_drops_ids_outside_the_vocabulary() {
        let pipeline = hello_pipeline();

        assert_eq!(pipeline.decode_tokens(&[7, 99, 4], false), ["hello", "he"]);
    }

    #[test]
    fn decode_tokens_skips_special_tokens_on_request() {
        use crate::vocab::bucket_added_vocabulary::AddedToken;

        let mut added = BucketAddedVocabulary::new();
        added
            .add_special_tokens(
                [AddedToken::from("<s>", true)],
                8,
                |_| None,
                None::<&PipelineNormalizer>,
            )
            .unwrap();
        let pipeline = PipelineTokenizer::from_parts(
            added,
            Vec::new(),
            PipelinePreTokenizer::None,
            PipelineModel::BPE(hello_bpe()),
            PipelinePostProcessor::default(),
            None,
            Default::default(),
            None,
            None,
        );

        assert_eq!(pipeline.decode_tokens(&[8, 7], false), ["<s>", "hello"]);
        assert_eq!(pipeline.decode_tokens(&[8, 7], true), ["hello"]);
    }

    #[test]
    fn decode_without_a_decoder_joins_tokens_with_a_space() {
        let pipeline = hello_pipeline();

        assert_eq!(pipeline.decode(&[7, 4], false).unwrap(), "hello he");
    }

    fn hello_bpe() -> PipelineBPE {
        use crate::models::bpe::{BpeConfig, Merges, Vocab};

        let vocab: Vocab = [
            ("h", 0u32),
            ("e", 1),
            ("l", 2),
            ("o", 3),
            ("he", 4),
            ("hel", 5),
            ("hell", 6),
            ("hello", 7),
        ]
        .into_iter()
        .map(|(s, i)| (s.to_string(), i))
        .collect();
        let merges: Merges = vec![
            ("h".to_string(), "e".to_string()),
            ("he".to_string(), "l".to_string()),
            ("hel".to_string(), "l".to_string()),
            ("hell".to_string(), "o".to_string()),
        ];
        PipelineBPE::from_config(BpeConfig {
            vocab,
            merges,
            ..BpeConfig::default()
        })
        .unwrap()
    }

    fn hello_pipeline() -> PipelineTokenizer {
        hello_pipeline_with(PipelinePostProcessor::default(), None, None)
    }

    fn hello_pipeline_with_special(content: &str) -> PipelineTokenizer {
        let mut added_vocabulary = BucketAddedVocabulary::new();
        added_vocabulary
            .add_special_tokens(
                [AddedToken::from(content, true)],
                8,
                |_| None,
                None::<&PipelineNormalizer>,
            )
            .unwrap();
        PipelineTokenizer::from_parts(
            added_vocabulary,
            Vec::new(),
            PipelinePreTokenizer::None,
            PipelineModel::BPE(hello_bpe()),
            PipelinePostProcessor::default(),
            None,
            Default::default(),
            None,
            None,
        )
    }

    fn hello_pipeline_with_padding(padding: PaddingParams) -> PipelineTokenizer {
        hello_pipeline_with(PipelinePostProcessor::default(), Some(padding), None)
    }

    fn hello_pipeline_with_truncation(truncation: TruncationParams) -> PipelineTokenizer {
        hello_pipeline_with(PipelinePostProcessor::default(), None, Some(truncation))
    }
}
