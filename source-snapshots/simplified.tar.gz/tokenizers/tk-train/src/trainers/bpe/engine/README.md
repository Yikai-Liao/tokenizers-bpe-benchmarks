# BPE training engine

The public entry is `BpeTrainer::do_train`. It consumes weighted words and returns
a vocabulary, merges in rank order, and special tokens. `feed` and `train` wrap
this entry with pretokenization and model construction. The engine owns one Rayon
pool per training call and uses the caller's configured worker count.

The implementation preserves weighted pair counts, ascending pair-ID tie breaks,
left-to-right overlap handling, affixes, reserved IDs, and active-ID reuse. Counts
use checked `u64` arithmetic; configurations that need a signed reuse ledger also
check its `i64` domain. Existing vocabulary IDs remain stable. Alphabet frequency
ties retain the public trainer's existing behavior.

## Reading order

| Module | Responsibility |
| --- | --- |
| `mod.rs` | Attempts, ID-reuse restart, certified rule selection and phase ordering |
| `vocabulary.rs` | Token strings, IDs, activation and original-byte symbol interpretation |
| `corpus/prepare.rs` | Weighted word ordering, checkpoints and deferred slot construction |
| `corpus/slots.rs` | 16-, 24- and 32-bit planes and their local safety contracts |
| `corpus/mod.rs` | Live endpoints, token spans, stale-position matching and disjoint writes |
| `initial_pairs.rs` | Bounded initial waves, stable full-key grouping and weighted counts |
| `pair_index.rs` | Candidate priorities, lazy count repair and birth-cohort ownership |
| `merge/mod.rs` | Prepare writes from a read-only snapshot, then apply after readers join |
| `merge/events.rs` | Compact event references and stable owner-local birth grouping |
| `aa_parity.rs` | Exact overlap selection across AA chunks |
| `execution.rs` | Pool and reusable worker resources, including error-path cleanup |
| `storage/` | Private coordinate storage, G128 encoding, allocation and ID directories |

[DESIGN.md](DESIGN.md) explains the semantics and the cost of the retained
optimizations. Safety arguments remain next to each unsafe operation.

## Correctness checks

From the repository root:

```sh
cargo test --manifest-path tokenizers/tk-train/Cargo.toml --lib
cargo test --manifest-path tokenizers/tk-train/Cargo.toml --no-default-features --lib
cargo test --manifest-path tokenizers/tk-train/Cargo.toml --lib \
  randomized_round_by_round_hf_stress -- --ignored
```

Tests compare vocabulary IDs, ordered merges and per-rule traces across worker
counts. Named cases cover ties, AA, affixes, filtering, ID reuse, strict birth
limits, overflow, zero-merge returns and segmented long words. Storage tests
exercise full-width positions, restart cursors, append failures, arena lifetime
and directory recovery. The small-input reference preserves upstream queue and
cohort behavior independently of engine storage; explicit expectations cover
wide-count boundaries beyond that reference's count domain.

## Performance evidence

Batching, G128 positions, bounded stable radix grouping, deferred corpus creation,
allocation reuse and weight cursors remain part of the implementation. Complete
producer rules encode their births directly; split rules retain the aggregation
path. The radix implementation keeps its original BSD license and full-key
stability contract. Sorting uses the existing implementation.

Reproduction tools and experiment records live in
[tokenizers-bpe-benchmarks](https://github.com/Yikai-Liao/tokenizers-bpe-benchmarks).
They record source and binary hashes, pinned corpus inputs, compiler settings,
affinity, public training time, CPU time, process HWM and exact output comparisons.
Measurements apply to their recorded machine and workloads.
