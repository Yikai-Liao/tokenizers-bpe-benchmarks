//! Prepare neighbor changes from one immutable snapshot, then join disjoint writes.
//! First activations permit independent rules to share a batch. Birth cohorts
//! select one rule and preserve each intermediate boundary produced by HF BPE.
mod events;
use super::storage::{AllocationArena, SortedPositions};
use super::storage::{IdAccumulator, IdDirectory, PositionBuffer, PositionChain, PositionChains};
use super::{
    IdentityPolicy, WORD_SEPARATOR_ID, aa_parity,
    corpus::{Corpus, PairMatch, PairMatcher, SlotStorage, WordWeightCursor},
    execution::Execution,
    pair_index::{MergeCandidate, PairState, pair_key},
};
use ahash::AHashMap;
pub(super) use events::{ChangeAction, EventChunk, MergeEvents, PairChanges};
use rayon::prelude::*;
use tk_encode::{Result, models::bpe::Pair};

#[derive(Clone, Copy)]
pub(super) struct MergeRule {
    pub(super) pair: Pair,
    pub(super) replacement: u32,
}
#[derive(Default)]
struct NeighborChanges {
    removed: u64,
    born: u64,
    positions: PositionChain,
}
struct WritePlan {
    rule: MergeRule,
    positions: PositionBuffer,
}
struct PreparedJob {
    writes: Vec<WritePlan>,
    word_region: Option<std::ops::Range<u64>>,
}
pub(super) struct PreparedMerges {
    jobs: Vec<PreparedJob>,
    events: MergeEvents,
}
pub(super) struct MergeScratch {
    left: IdAccumulator<NeighborChanges>,
    right: IdAccumulator<NeighborChanges>,
    chains: PositionChains,
    changes: Vec<PairChanges>,
    remaining_nodes: usize,
}
impl MergeScratch {
    pub(super) fn new(token_id_count: usize, directories: [IdDirectory; 2]) -> Self {
        let [left, right] = directories;
        Self {
            left: IdAccumulator::with_directory(token_id_count, left),
            right: IdAccumulator::with_directory(token_id_count, right),
            chains: PositionChains::new(),
            changes: Vec::new(),
            remaining_nodes: PositionChains::MAX_NODES,
        }
    }
    pub(super) fn into_directories(self) -> [IdDirectory; 2] {
        [self.left.into_directory(), self.right.into_directory()]
    }
    // PERF: Rules in one job share their node allocation. Drain only the
    // neighbor directories between rules; handing off nodes here would create
    // a separately growing allocation for every rule and prevent buffer reuse.
    fn flush_rule(&mut self, rule: &MergeRule, rank: usize) {
        for (neighbor, change) in self.left.drain() {
            self.changes.push(PairChanges {
                removed_key: pair_key((neighbor, rule.pair.0)),
                born_key: pair_key((neighbor, rule.replacement)),
                removed_weight: change.removed,
                born_weight: change.born,
                positions: change.positions,

                bucket: (rank * 2) as u32,
            });
        }
        for (neighbor, change) in self.right.drain() {
            self.changes.push(PairChanges {
                removed_key: pair_key((rule.pair.1, neighbor)),
                born_key: pair_key((rule.replacement, neighbor)),
                removed_weight: change.removed,
                born_weight: change.born,
                positions: change.positions,

                bucket: (rank * 2 + usize::from(neighbor != rule.replacement)) as u32,
            });
        }
    }
    fn flush_rule_with_births<'a>(
        &mut self,
        rule: &MergeRule,
        rank: usize,
        floor: u64,
        arena: &'a AllocationArena,
        execution: &Execution,
        direct: bool,
        births: &mut Vec<(u64, PairState<'a>)>,
    ) -> Result<()> {
        let worker = execution.current_worker();
        let lease = arena.lease(worker);
        let mut encoding = (!direct).then(|| execution.encoding(worker));
        let chains = &self.chains;
        let changes = &mut self.changes;
        // These are the original neighbor-directory drains, not a second pass
        // over emitted events. Each birth already has its complete mass/chain.
        let mut emit = |mut event: PairChanges| -> Result<()> {
            if !event.positions.is_empty() {
                if event.born_weight >= floor {
                    let occurrences = event.positions.len();
                    let positions = if let Some(encoding) = encoding.as_deref_mut() {
                        SortedPositions::from_reversed_iter(
                            occurrences,
                            chains.reversed(event.positions),
                            encoding,
                            &lease,
                        )?
                    } else {
                        SortedPositions::from_reversed_iter_direct(
                            occurrences,
                            chains.reversed(event.positions),
                            &lease,
                        )?
                    };

                    births.push((
                        event.born_key,
                        PairState {
                            ledger_count_bits: event.born_weight,
                            positions,
                        },
                    ));
                }
            }
            // No birth event is emitted for the completed producer. The count
            // owner's original removal actions retain their keys and weights.
            if event.removed_weight != 0 {
                event.positions = PositionChain::default();
                changes.push(event);
            }
            Ok(())
        };
        for (neighbor, change) in self.left.drain() {
            emit(PairChanges {
                removed_key: pair_key((neighbor, rule.pair.0)),
                born_key: pair_key((neighbor, rule.replacement)),
                removed_weight: change.removed,
                born_weight: change.born,
                positions: change.positions,
                bucket: (rank * 2) as u32,
            })?;
        }
        for (neighbor, change) in self.right.drain() {
            emit(PairChanges {
                removed_key: pair_key((rule.pair.1, neighbor)),
                born_key: pair_key((rule.replacement, neighbor)),
                removed_weight: change.removed,
                born_weight: change.born,
                positions: change.positions,
                bucket: (rank * 2 + usize::from(neighbor != rule.replacement)) as u32,
            })?;
        }
        Ok(())
    }
    fn take_chunk(&mut self) -> EventChunk {
        self.remaining_nodes = PositionChains::MAX_NODES;
        EventChunk {
            chains: std::mem::take(&mut self.chains),
            changes: std::mem::take(&mut self.changes),
        }
    }
    fn remove(group: &mut NeighborChanges, weight: u64) -> Result<()> {
        group.removed = group
            .removed
            .checked_add(weight)
            .ok_or("BPE neighbor removal mass exceeds u64")?;
        Ok(())
    }
    // PERF: This update runs for every newborn boundary. Expose its small
    // successful path to the caller so count and chain updates share local
    // values; overflow error construction must not keep it out of line.
    #[inline(always)]
    fn birth(
        group: &mut NeighborChanges,
        chains: &mut PositionChains,
        remaining_nodes: &mut usize,
        position: u64,
        weight: u64,
    ) -> Result<()> {
        group.born = group
            .born
            .checked_add(weight)
            .ok_or("BPE neighbor birth mass exceeds u64")?;
        chains.push(&mut group.positions, position)?;
        *remaining_nodes -= 1;
        Ok(())
    }
    fn left(&mut self, neighbor: u32, position: u64, weight: u64, birth: bool) -> Result<()> {
        let group = self.left.touch(neighbor);
        Self::remove(group, weight)?;
        if birth {
            Self::birth(
                group,
                &mut self.chains,
                &mut self.remaining_nodes,
                position,
                weight,
            )?;
        }
        Ok(())
    }
    fn right(
        &mut self,
        removed: u32,
        born: u32,
        position: u64,
        weight: u64,
        birth: bool,
    ) -> Result<()> {
        let group = self.right.touch(removed);
        Self::remove(group, weight)?;
        if birth {
            // A cohort keeps the same neighbor on removal and birth. Preserve
            // checked removal-before-birth order while sharing its lookup.
            let group = if removed == born {
                group
            } else {
                self.right.touch(born)
            };
            Self::birth(
                group,
                &mut self.chains,
                &mut self.remaining_nodes,
                position,
                weight,
            )?;
        }
        Ok(())
    }
}
// PERF: Prefetch a bounded distance ahead to overlap scattered endpoint loads
// without retaining a fully decoded position list.
const PREFETCH_DISTANCE: usize = 16;
const EMPTY: u64 = u64::MAX;
const MULTIPLE: u64 = u64::MAX - 1;
/// Dense directories recognize selected neighbors without a hash lookup in the
/// common case. Shared heads or tails use the complete-key map.
#[derive(Default)]
pub(super) struct SelectedRuleIndex {
    heads: Vec<u64>,
    tails: Vec<u64>,
    multiple: AHashMap<u64, u32>,
    pairs: Vec<Pair>,
}
impl SelectedRuleIndex {
    fn reset(&mut self, rules: &[MergeRule], token_id_count: usize) {
        for (head, tail) in self.pairs.drain(..) {
            self.heads[head as usize] = EMPTY;
            self.tails[tail as usize] = EMPTY;
        }
        self.heads.resize(token_id_count, EMPTY);
        self.tails.resize(token_id_count, EMPTY);
        self.multiple.clear();
        for rule in rules {
            self.pairs.push(rule.pair);
            let head = &mut self.heads[rule.pair.0 as usize];
            *head = if *head == EMPTY {
                pair_key((rule.pair.1, rule.replacement))
            } else {
                MULTIPLE
            };
            let tail = &mut self.tails[rule.pair.1 as usize];
            *tail = if *tail == EMPTY {
                pair_key((rule.pair.0, rule.replacement))
            } else {
                MULTIPLE
            };
        }
        for rule in rules {
            if self.heads[rule.pair.0 as usize] == MULTIPLE
                || self.tails[rule.pair.1 as usize] == MULTIPLE
            {
                self.multiple.insert(pair_key(rule.pair), rule.replacement);
            }
        }
    }
    fn left_selected<S: SlotStorage>(&self, corpus: &Corpus<S>, before: u64, prior: u32) -> bool {
        let tail = self.tails[prior as usize];
        if tail == EMPTY {
            return false;
        }
        let previous = corpus.token(before - 1);
        if tail == MULTIPLE {
            self.multiple.contains_key(&pair_key((previous, prior)))
        } else {
            (tail >> 32) as u32 == previous
        }
    }
    fn final_next<S: SlotStorage>(&self, corpus: &Corpus<S>, after: u64, next: u32) -> u32 {
        let head = self.heads[next as usize];
        if head == EMPTY {
            return next;
        }
        let following = corpus.token(after + corpus.span_by_id(next));
        if head == MULTIPLE {
            self.multiple
                .get(&pair_key((next, following)))
                .copied()
                .unwrap_or(next)
        } else if (head >> 32) as u32 == following {
            head as u32
        } else {
            next
        }
    }
}
#[derive(Clone, Copy)]
struct LogicalToken {
    id: u32,
    start: u64,
    span: u64,
}
enum SelectedNeighbors<'a> {
    Rules(&'a SelectedRuleIndex),
    Adjacent {
        previous: Option<u64>,
        following: Option<u64>,
    },
}
struct RulePreparation<'a, S: SlotStorage> {
    corpus: &'a Corpus<S>,
    scratch: &'a mut MergeScratch,
    rule: &'a MergeRule,
    rank: usize,
    matcher: PairMatcher<'a, S>,
    birth_span_limit: u64,
    chunks: Vec<EventChunk>,
    positions: PositionBuffer,
    // PERF: Weighted words are contiguous and often share weights. Cache the
    // current interval across sorted occurrence visits instead of searching
    // immutable boundaries for every rewrite. The cursor also handles resets.
    weights: WordWeightCursor<'a>,
}
impl<S: SlotStorage> RulePreparation<'_, S> {
    fn room(&mut self) {
        if self.scratch.remaining_nodes < 2 {
            self.scratch.flush_rule(self.rule, self.rank);
            self.chunks.push(self.scratch.take_chunk());
        }
    }
    fn record_cohort_match(
        &mut self,
        matched: PairMatch,
        previous: Option<LogicalToken>,
    ) -> Result<LogicalToken> {
        self.room();
        let weight = self.weights.weight(matched.left_start);
        if let Some(previous) = previous {
            self.scratch.left(
                previous.id,
                previous.start,
                weight,
                previous.span + matched.merged_span < self.birth_span_limit,
            )?;
        }
        let next = self.corpus.token(matched.next_start);
        if next != WORD_SEPARATOR_ID {
            self.scratch.right(
                next,
                next,
                matched.left_start,
                weight,
                matched.merged_span + self.corpus.span(matched.next_start) < self.birth_span_limit,
            )?;
        }
        self.positions.push_position(matched.left_start);
        Ok(LogicalToken {
            id: self.rule.replacement,
            start: matched.left_start,
            span: matched.merged_span,
        })
    }
    fn fresh(&mut self, matched: PairMatch, neighbors: SelectedNeighbors<'_>) -> Result<()> {
        self.room();
        let weight = self.weights.weight(matched.left_start);
        let prior = self.corpus.token(matched.left_start - 1);
        if prior != WORD_SEPARATOR_ID {
            let prior_span = self.corpus.span_by_id(prior);
            let before = matched.left_start - prior_span;
            let left_selected = match neighbors {
                SelectedNeighbors::Adjacent { previous, .. } => {
                    previous.is_some_and(|start| start + matched.merged_span == matched.left_start)
                }
                SelectedNeighbors::Rules(selected) => {
                    selected.left_selected(self.corpus, before, prior)
                }
            };
            if !left_selected {
                self.scratch.left(
                    prior,
                    before,
                    weight,
                    prior_span + matched.merged_span < self.birth_span_limit,
                )?;
            }
        }
        let next = self.corpus.token(matched.next_start);
        if next != WORD_SEPARATOR_ID {
            let final_next = match neighbors {
                SelectedNeighbors::Adjacent { following, .. } => {
                    if following == Some(matched.next_start) {
                        self.rule.replacement
                    } else {
                        next
                    }
                }
                SelectedNeighbors::Rules(selected) => {
                    selected.final_next(self.corpus, matched.next_start, next)
                }
            };
            self.scratch.right(
                next,
                final_next,
                matched.left_start,
                weight,
                matched.merged_span + self.corpus.span_by_id(final_next) < self.birth_span_limit,
            )?;
        }
        Ok(())
    }
    fn finish_with_births<'a>(
        self,
        arena: &'a AllocationArena,
        execution: &Execution,
        floor: u64,
        direct: bool,
        births: &mut Vec<(u64, PairState<'a>)>,
    ) -> Result<(WritePlan, Vec<EventChunk>)> {
        debug_assert!(
            self.chunks.is_empty(),
            "allocation node budget excludes partial flush"
        );
        self.scratch.flush_rule_with_births(
            self.rule, self.rank, floor, arena, execution, direct, births,
        )?;
        Ok((
            WritePlan {
                rule: *self.rule,
                positions: self.positions,
            },
            self.chunks,
        ))
    }
    fn finish(self) -> (WritePlan, Vec<EventChunk>) {
        self.scratch.flush_rule(self.rule, self.rank);
        (
            WritePlan {
                rule: *self.rule,
                positions: self.positions,
            },
            self.chunks,
        )
    }
}
struct PositionTask {
    rank: usize,
    begin: usize,
    end: usize,
    full: bool,
    fast: bool,
}
impl PositionTask {
    fn new(rank: usize, begin: usize, end: usize, total: usize) -> Self {
        Self {
            rank,
            begin,
            end,
            full: begin == 0 && end == total,
            fast: false,
        }
    }
}
fn job_node_budget_fits(tasks: &[PositionTask], capacity: usize) -> bool {
    tasks
        .iter()
        .try_fold(0usize, |total, task| {
            total.checked_add(task.end - task.begin)
        })
        .and_then(|total| total.checked_mul(2))
        .is_some_and(|nodes| nodes <= capacity)
}
#[derive(Clone, Copy, Debug)]
pub(super) struct MergeOptions {
    pub(super) single_producer_fast: bool,
    pub(super) direct_encoding: bool,
}
impl Default for MergeOptions {
    fn default() -> Self {
        Self {
            single_producer_fast: true,
            direct_encoding: true,
        }
    }
}
fn position_jobs(
    candidates: &[MergeCandidate<'_>],
    workers: usize,
    fast_enabled: bool,
) -> Vec<Vec<PositionTask>> {
    let mut jobs = if workers == 1 {
        position_jobs_grid(candidates, workers)
    } else {
        position_jobs_whole(candidates, workers)
    };
    if fast_enabled {
        let capacity = PositionChains::MAX_NODES;
        for job in &mut jobs {
            if job_node_budget_fits(job, capacity) {
                for task in job {
                    task.fast = task.full;
                }
            }
        }
    }
    jobs
}
fn position_jobs_grid(candidates: &[MergeCandidate<'_>], workers: usize) -> Vec<Vec<PositionTask>> {
    let total: usize = candidates
        .iter()
        .map(|candidate| candidate.positions.len())
        .sum();
    let chunk = total.div_ceil(workers).clamp(1, 1 << 26);
    let mut jobs = Vec::<Vec<PositionTask>>::new();
    let mut visited = 0;
    for (rank, candidate) in candidates.iter().enumerate() {
        let mut begin = 0;
        while begin < candidate.positions.len() {
            let job = visited / chunk;
            if job == jobs.len() {
                jobs.push(Vec::new());
            }
            let take = (chunk - visited % chunk).min(candidate.positions.len() - begin);
            jobs[job].push(PositionTask::new(
                rank,
                begin,
                begin + take,
                candidate.positions.len(),
            ));
            visited += take;
            begin += take;
        }
    }
    jobs
}

fn position_jobs_whole(
    candidates: &[MergeCandidate<'_>],
    workers: usize,
) -> Vec<Vec<PositionTask>> {
    let total: usize = candidates
        .iter()
        .map(|candidate| candidate.positions.len())
        .sum();
    let chunk = total.div_ceil(workers).clamp(1, 1 << 26);
    let tail_budget = chunk.div_ceil(128).min(64);
    // Keep ordinary pairs intact and expose more ready jobs to the pool.
    // Small pairs share a job; large pairs retain the original maximum range.
    let grain = total
        .div_ceil(workers.saturating_mul(4))
        .max(4096)
        .min(chunk);
    let mut jobs = Vec::<Vec<PositionTask>>::new();
    let mut filled = chunk;
    for (rank, candidate) in candidates.iter().enumerate() {
        let count = candidate.positions.len();
        if count == 0 {
            continue;
        }
        if count <= chunk {
            if filled >= grain || filled + count > grain {
                jobs.push(Vec::new());
                filled = 0;
            }
            jobs.last_mut()
                .expect("the current job exists")
                .push(PositionTask::new(rank, 0, count, count));
            filled += count;
            continue;
        }
        // A large candidate gets spatially ordered ranges, without increasing
        // its producer count merely to reach the smaller scheduling grain.
        let mut begin = 0;
        while begin < count {
            let remaining = count - begin;
            let mut take = chunk.min(remaining);
            if remaining - take <= tail_budget {
                take = remaining;
            }
            jobs.push(vec![PositionTask::new(
                rank,
                begin,
                begin + take,
                candidate.positions.len(),
            )]);
            begin += take;
        }
        filled = chunk;
    }
    jobs
}

fn preparation<'a, S: SlotStorage>(
    corpus: &'a Corpus<S>,
    scratch: &'a mut MergeScratch,
    rule: &'a MergeRule,
    rank: usize,
    birth_span_limit: u64,
) -> RulePreparation<'a, S> {
    RulePreparation {
        corpus,
        scratch,
        rule,
        rank,
        matcher: corpus.matcher(rule.pair),
        birth_span_limit,
        chunks: Vec::new(),
        positions: PositionBuffer::default(),
        weights: corpus.weight_cursor(),
    }
}
pub(super) fn prepare_merges<S: SlotStorage>(
    corpus: &Corpus<S>,
    rules: &[MergeRule],
    candidates: &[MergeCandidate<'_>],
    policy: IdentityPolicy,
    token_id_count: usize,
    birth_span_limit: usize,
    execution: &Execution,
) -> Result<PreparedMerges> {
    prepare_merges_core(
        corpus,
        rules,
        candidates,
        policy,
        token_id_count,
        birth_span_limit,
        execution,
        None,
        1,
        MergeOptions::default(),
    )
    .map(|(prepared, _)| prepared)
}
pub(super) fn prepare_merges_with_births<'a, S: SlotStorage>(
    corpus: &Corpus<S>,
    rules: &[MergeRule],
    candidates: &[MergeCandidate<'_>],
    policy: IdentityPolicy,
    token_id_count: usize,
    birth_span_limit: usize,
    execution: &Execution,
    arena: &'a AllocationArena,
    floor: u64,
    options: MergeOptions,
) -> Result<(PreparedMerges, Vec<(u64, PairState<'a>)>)> {
    // Reuse and AA preserve their original preparation and ownership path.
    if policy == IdentityPolicy::AllowActiveReuse || rules[0].pair.0 == rules[0].pair.1 {
        return prepare_merges(
            corpus,
            rules,
            candidates,
            policy,
            token_id_count,
            birth_span_limit,
            execution,
        )
        .map(|prepared| (prepared, Vec::new()));
    }
    prepare_merges_core(
        corpus,
        rules,
        candidates,
        policy,
        token_id_count,
        birth_span_limit,
        execution,
        Some(arena),
        floor.max(1),
        options,
    )
}
fn prepare_merges_core<'a, S: SlotStorage>(
    corpus: &Corpus<S>,
    rules: &[MergeRule],
    candidates: &[MergeCandidate<'_>],
    policy: IdentityPolicy,
    token_id_count: usize,
    birth_span_limit: usize,
    execution: &Execution,
    arena: Option<&'a AllocationArena>,
    floor: u64,
    options: MergeOptions,
) -> Result<(PreparedMerges, Vec<(u64, PairState<'a>)>)> {
    let outputs = if policy == IdentityPolicy::AllowActiveReuse {
        prepare_cohort(
            corpus,
            &rules[0],
            &candidates[0],
            token_id_count,
            birth_span_limit as u64,
            execution,
        )?
        .into_iter()
        .map(|(job, chunks)| (job, chunks, Vec::new()))
        .collect()
    } else if rules[0].pair.0 == rules[0].pair.1 {
        prepare_aa(
            corpus,
            &rules[0],
            &candidates[0],
            token_id_count,
            birth_span_limit as u64,
            execution,
        )?
        .into_iter()
        .map(|(job, chunks)| (job, chunks, Vec::new()))
        .collect()
    } else {
        let jobs = position_jobs(
            candidates,
            execution.workers(),
            options.single_producer_fast && arena.is_some(),
        );
        let mut selected = execution.selected_rules();
        selected.reset(rules, token_id_count);

        let outputs = jobs
            .into_par_iter()
            .map(|tasks| -> Result<_> {
                execution.with_merge_scratch(token_id_count, |scratch| {
                    let mut outputs = Vec::new();
                    let mut births = Vec::new();
                    for task in tasks {
                        let mut plan = preparation(
                            corpus,
                            scratch,
                            &rules[task.rank],
                            task.rank,
                            birth_span_limit as u64,
                        );
                        let mut cursor =
                            candidates[task.rank].positions.cursor(task.begin..task.end);
                        // PERF: Interleave decoding and consumption through a small
                        // ring. Each newly decoded position is prefetched one ring
                        // ahead of its endpoint loads, without a full decoded tile.
                        let mut ring = [0; PREFETCH_DISTANCE];
                        let mut active = cursor.decode_into(&mut ring);
                        for &position in &ring[..active] {
                            corpus.prefetch(position);
                        }
                        let mut head = 0;
                        while active != 0 {
                            let position = ring[head];
                            if let Some(next) = cursor.next() {
                                ring[head] = next;
                                corpus.prefetch(next);
                            } else {
                                active -= 1;
                            }
                            head = (head + 1) % PREFETCH_DISTANCE;
                            if let Some(matched) = plan.matcher.get(position) {
                                plan.fresh(matched, SelectedNeighbors::Rules(&selected))?;
                                plan.positions.push_position(position);
                            }
                        }

                        if task.fast {
                            outputs.push(plan.finish_with_births(
                                arena.expect("fast tasks have an arena"),
                                execution,
                                floor,
                                options.direct_encoding,
                                &mut births,
                            )?);
                        } else {
                            outputs.push(plan.finish());
                        }
                    }
                    if let Some((_, chunks)) = outputs.last_mut() {
                        chunks.push(scratch.take_chunk());
                    }

                    let (writes, chunks): (Vec<_>, Vec<_>) = outputs.into_iter().unzip();
                    let chunks = chunks.into_iter().flatten().collect::<Vec<_>>();

                    Ok((
                        PreparedJob {
                            writes,
                            word_region: None,
                        },
                        chunks,
                        births,
                    ))
                })
            })
            .collect::<Result<Vec<_>>>()?;

        outputs
    };
    let mut jobs = Vec::new();
    let mut chunks = Vec::new();
    let mut births = Vec::new();
    for (write, events, encoded) in outputs {
        births.extend(encoded);
        jobs.push(write);
        chunks.extend(events);
    }
    Ok((
        PreparedMerges {
            jobs,
            events: MergeEvents {
                chunks,
                buckets: rules.len() * 2,
            },
        },
        births,
    ))
}
enum CohortSource {
    Words(Vec<usize>),
    Positions(std::ops::Range<usize>),
}
struct CohortTask {
    region: std::ops::Range<u64>,
    source: CohortSource,
}
fn prepare_cohort<S: SlotStorage>(
    corpus: &Corpus<S>,
    rule: &MergeRule,
    candidate: &MergeCandidate<'_>,
    token_id_count: usize,
    birth_span_limit: u64,
    execution: &Execution,
) -> Result<Vec<(PreparedJob, Vec<EventChunk>)>> {
    let count = candidate.positions.len();
    let chunk = count.div_ceil(execution.workers()).max(1);
    let tasks = if corpus.needs_word_scan() {
        // Ordered cohorts make word IDs nondecreasing. Each range caches its
        // current word, then adjacent dedup joins range boundaries as well.
        let parts: Vec<Vec<usize>> = (0..count)
            .step_by(chunk)
            .collect::<Vec<_>>()
            .into_par_iter()
            .map(|begin| {
                let mut words = Vec::new();
                let mut current = None;
                for position in candidate
                    .positions
                    .cursor(begin..(begin + chunk).min(count))
                {
                    let word = match current {
                        Some((word, end)) if position < end => word,
                        _ => corpus.word_containing(position),
                    };
                    current = Some((word, corpus.word_end(word)));
                    if words.last() != Some(&word) {
                        words.push(word);
                    }
                }
                words
            })
            .collect();
        let mut words: Vec<_> = parts.into_iter().flatten().collect();
        words.dedup();
        let chunk = words.len().div_ceil(execution.workers()).max(1);
        words
            .chunks(chunk)
            .enumerate()
            .map(|(index, part)| {
                let start = if index == 0 {
                    0
                } else {
                    corpus.word_start(part[0])
                };
                let end = words
                    .get((index + 1) * chunk)
                    .map_or(corpus.len() as u64, |&word| corpus.word_start(word));
                CohortTask {
                    region: start..end,
                    source: CohortSource::Words(part.to_vec()),
                }
            })
            .collect::<Vec<_>>()
    } else {
        // Before alias reuse or a length gate, only cut boundaries need a word
        // lookup. Move each cut to the first occurrence in that complete word.
        let mut cuts = vec![(0, 0)];
        for desired in (chunk..count).step_by(chunk) {
            let position = candidate
                .positions
                .cursor(desired..desired + 1)
                .next()
                .expect("the cut index belongs to the cohort");
            let pivot = corpus.word_start(corpus.word_containing(position));
            let begin = candidate.positions.lower_bound(pivot);
            if begin > cuts.last().expect("the first cut exists").0 {
                cuts.push((begin, pivot));
            }
        }
        cuts.push((count, corpus.len() as u64));
        cuts.windows(2)
            .map(|cuts| CohortTask {
                region: cuts[0].1..cuts[1].1,
                source: CohortSource::Positions(cuts[0].0..cuts[1].0),
            })
            .collect()
    };
    tasks
        .into_par_iter()
        .map(|task| -> Result<_> {
            execution.with_merge_scratch(token_id_count, |scratch| {
                let mut plan = preparation(corpus, scratch, rule, 0, birth_span_limit);
                match task.source {
                    CohortSource::Words(words) => {
                        for word in words {
                            let mut previous = None;
                            let mut position = corpus.word_start(word);
                            while corpus.token(position) != WORD_SEPARATOR_ID {
                                if let Some(matched) = plan.matcher.get(position) {
                                    previous = Some(plan.record_cohort_match(matched, previous)?);
                                    position = matched.next_start;
                                } else {
                                    let span = corpus.span(position);
                                    previous = Some(LogicalToken {
                                        id: corpus.token(position),
                                        start: position,
                                        span,
                                    });
                                    position += span;
                                }
                            }
                        }
                    }
                    CohortSource::Positions(range) => {
                        let mut previous = None;
                        let mut after = task.region.start;
                        for position in candidate.positions.cursor(range) {
                            if position < after {
                                continue;
                            }
                            if let Some(matched) = plan.matcher.get(position) {
                                if position != after {
                                    let id = corpus.token(position - 1);
                                    previous = (id != WORD_SEPARATOR_ID).then(|| {
                                        let span = corpus.span(position - 1);
                                        LogicalToken {
                                            id,
                                            start: position - span,
                                            span,
                                        }
                                    });
                                }
                                previous = Some(plan.record_cohort_match(matched, previous)?);
                                after = matched.next_start;
                            }
                        }
                    }
                }
                let (write, mut chunks) = plan.finish();
                chunks.push(scratch.take_chunk());

                Ok((
                    PreparedJob {
                        writes: vec![write],
                        word_region: Some(task.region),
                    },
                    chunks,
                ))
            })
        })
        .collect()
}
fn prepare_aa<S: SlotStorage>(
    corpus: &Corpus<S>,
    rule: &MergeRule,
    candidate: &MergeCandidate<'_>,
    token_id_count: usize,
    birth_span_limit: u64,
    execution: &Execution,
) -> Result<Vec<(PreparedJob, Vec<EventChunk>)>> {
    let chunk = candidate
        .positions
        .len()
        .div_ceil(execution.workers())
        .clamp(1, 1 << 26);
    let ranges: Vec<_> = (0..candidate.positions.len())
        .step_by(chunk)
        .map(|begin| begin..(begin + chunk).min(candidate.positions.len()))
        .collect();
    let matcher = corpus.matcher(rule.pair);
    let valid: Vec<_> = ranges
        .into_par_iter()
        .map(|range| {
            let mut positions = PositionBuffer::default();
            for position in candidate.positions.cursor(range) {
                if matcher.get(position).is_some() {
                    positions.push_position(position);
                }
            }
            positions
        })
        .collect();
    let span = corpus.span_by_id(rule.pair.0);
    let summaries: Vec<_> = valid
        .iter()
        .map(|positions| {
            aa_parity::summarize_by(positions.len(), |index| positions.position(index), span)
        })
        .collect();
    let parities = aa_parity::incoming_parities(&summaries, span);
    let chosen: Vec<_> = valid
        .into_par_iter()
        .zip(parities)
        .map(|(positions, parity)| {
            let mut chosen = PositionBuffer::default();
            aa_parity::for_each_selected(positions.positions(), span, parity, |position| {
                chosen.push_position(position)
            });
            chosen
        })
        .collect();
    let mut previous = Vec::with_capacity(chosen.len());
    let mut last = None;
    for positions in &chosen {
        previous.push(last);
        if !positions.is_empty() {
            last = Some(positions.position(positions.len() - 1));
        }
    }
    let mut following = vec![None; chosen.len()];
    let mut first = None;
    for (index, positions) in chosen.iter().enumerate().rev() {
        following[index] = first;
        if !positions.is_empty() {
            first = Some(positions.position(0));
        }
    }
    chosen
        .into_par_iter()
        .enumerate()
        .map(|(index, positions)| -> Result<_> {
            execution.with_merge_scratch(token_id_count, |scratch| {
                let mut plan = preparation(corpus, scratch, rule, 0, birth_span_limit);
                for (offset, position) in positions.positions().enumerate() {
                    let previous = if offset == 0 {
                        previous[index]
                    } else {
                        Some(positions.position(offset - 1))
                    };
                    let following = if offset + 1 == positions.len() {
                        following[index]
                    } else {
                        Some(positions.position(offset + 1))
                    };
                    let matched = matcher.geometry(position);
                    plan.fresh(
                        matched,
                        SelectedNeighbors::Adjacent {
                            previous,
                            following,
                        },
                    )?;
                }
                plan.positions = positions;
                let (write, mut chunks) = plan.finish();
                chunks.push(scratch.take_chunk());

                Ok((
                    PreparedJob {
                        writes: vec![write],
                        word_region: None,
                    },
                    chunks,
                ))
            })
        })
        .collect()
}
impl PreparedMerges {
    pub(super) fn apply<S: SlotStorage>(self, corpus: &mut Corpus<S>) -> MergeEvents {
        if corpus.has_occurrence_spans() {
            let regions: Vec<_> = self
                .jobs
                .iter()
                .map(|job| {
                    job.word_region
                        .clone()
                        .expect("occurrence spans require complete whole-word jobs")
                })
                .collect();
            let writers = corpus
                .word_writers(&regions)
                .expect("the occurrence plane is materialized");
            self.jobs
                .par_iter()
                .zip(writers.into_par_iter())
                .for_each(|(job, mut writer)| {
                    for write in &job.writes {
                        write
                            .positions
                            .positions()
                            .for_each(|position| writer.merge(position, write.rule.replacement));
                    }
                });
        } else {
            self.jobs.par_iter().for_each(|job| {
                for write in &job.writes {
                    let matcher = corpus.matcher(write.rule.pair);
                    write.positions.positions().for_each(|position| {
                        // SAFETY: preparation selected disjoint endpoint spans.
                        // apply holds the mutable corpus borrow until pool join;
                        // geometry reads immutable ID spans, never token IDs.
                        unsafe {
                            corpus.write_endpoints(
                                matcher.geometry(position),
                                write.rule.replacement,
                            );
                        }
                    });
                }
            });
        }
        self.events
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn selected_rule_reuse_clears_shared_endpoints_before_domain_growth() {
        let mut selected = SelectedRuleIndex::default();
        selected.reset(
            &[
                MergeRule {
                    pair: (1, 2),
                    replacement: 4,
                },
                MergeRule {
                    pair: (1, 3),
                    replacement: 5,
                },
            ],
            6,
        );
        assert_eq!(selected.heads[1], MULTIPLE);
        assert_eq!(selected.multiple.len(), 2);
        selected.reset(
            &[MergeRule {
                pair: (3, 6),
                replacement: 7,
            }],
            8,
        );
        assert_eq!(selected.heads[1], EMPTY);
        assert_eq!(selected.tails[2], EMPTY);
        assert_eq!(selected.tails[3], EMPTY);
        assert!(selected.multiple.is_empty());
        assert_eq!(selected.heads[3], pair_key((6, 7)));
        assert_eq!(selected.tails[6], pair_key((3, 7)));
        selected.reset(&[], 8);
        assert_eq!(selected.heads[3], EMPTY);
        assert_eq!(selected.tails[6], EMPTY);
    }
}

#[cfg(test)]
mod producer_budget_tests {
    use super::*;
    #[test]
    fn node_budget_includes_partial_tasks_and_accepts_exact_capacity() {
        let tasks = [
            PositionTask::new(0, 0, 4, 4),
            PositionTask::new(1, 3, 8, 12),
        ];
        assert!(tasks[0].full);
        assert!(!tasks[1].full);
        assert!(job_node_budget_fits(&tasks, 18));
        assert!(!job_node_budget_fits(&tasks, 17));
        assert!(!job_node_budget_fits(
            &[PositionTask::new(0, 0, usize::MAX, usize::MAX)],
            usize::MAX
        ));
        assert!(!job_node_budget_fits(
            &[
                PositionTask::new(0, 0, usize::MAX, usize::MAX),
                PositionTask::new(1, 0, 1, 1)
            ],
            usize::MAX
        ));
    }
}
